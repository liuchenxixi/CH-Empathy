# Data Access Terms

This public release contains metadata, scripts, documentation, and aggregate results. It intentionally excludes restricted or sensitive row-level data.

## CGSS2023

CGSS2023 raw data must be obtained from the official CGSS provider. This package does not grant any right to redistribute CGSS files or row-level derivatives reconstructed from CGSS records.

## Seed survey

Seed-survey row-level records are not included in this public package because they may contain sensitive demographic, socioeconomic, and psychological variables. Public release should be limited to metadata and aggregate statistics unless consent and ethics approval explicitly allow row-level redistribution.

## Acceptable use

The included materials are intended for research, review, and reproducibility. Users should not attempt to identify individuals or link reconstructed records with external personal data.

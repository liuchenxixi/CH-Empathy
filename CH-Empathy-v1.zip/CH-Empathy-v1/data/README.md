# Data Directory

This directory is intentionally empty in the public package. Obtain CGSS2023 from the official provider and use `scripts/reconstruct_cgss2023.py` to reconstruct local derived tables.

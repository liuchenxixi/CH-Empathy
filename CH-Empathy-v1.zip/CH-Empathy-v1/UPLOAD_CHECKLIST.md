# Upload Checklist for DOI Release

## Repository

Recommended repositories: Zenodo, Dataverse, Datorium, or another archive that assigns a persistent DOI and supports versioned records.

## Files to upload

Upload `CH-Empathy-v1.zip` as a single archive. Do not upload loose raw files.

## Required metadata fields

- Title: CH-Empathy v1: A Weak-Empathy Resource with CGSS2023-Compatible Social Variables
- Resource type: Dataset / Software / Benchmark resource
- Version: v1.0.0
- Creators: replace with final author list and ORCID identifiers where available
- Keywords: empathy computing; weak supervision; social survey; CGSS2023; tabular benchmark; construct validity
- License: Mixed license. MIT for code; CC BY 4.0 for metadata, documentation, and aggregate results; third-party CGSS data excluded.
- Access rights: Open for metadata, scripts, documentation, and aggregate results. Restricted third-party row-level data are not redistributed.
- Related identifiers: add the paper DOI after publication, and add the GitHub URL if a public repository is created.

## Before submission

- Replace placeholder author names in `CITATION.cff`.
- Add the assigned DOI to the paper's resource availability paragraph.
- Confirm that no `.dta`, `.sav`, `.xlsx`, raw survey export, row-level CGSS-derived table, or seed-survey row-level file is included.
- Confirm that participant-consent and ethics statements in the paper match the actual approval documents.
- Confirm that CGSS redistribution terms permit the reconstruction-script release strategy.

## Paper wording after DOI is assigned

Suggested sentence:

"The CH-Empathy v1 metadata, documentation, reconstruction scripts, benchmark scripts, split configuration, and aggregate results are archived at DOI:XX.XXXX/zenodo.XXXXXXX. CGSS2023 raw records and CGSS-derived row-level tables are not redistributed; authorized users can reconstruct them locally using the released scripts."

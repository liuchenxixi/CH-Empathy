# CH-Empathy v1

CH-Empathy is a weak-empathy resource built from an IRI seed survey and a CGSS2023-compatible social-variable schema. This archive is prepared for DOI-based release through Zenodo, Dataverse, Datorium, or a similar repository.

## Included

- Metadata for semantic variables, recoding rules, one-hot feature names, and variable descriptions.
- Scripts for reconstructing CGSS2023-derived feature tables from an authorized local CGSS2023 copy.
- Teacher-model, benchmark, and construct-validity scripts.
- Aggregate benchmark and validation result tables used by the paper.
- Split configuration for reproducing the reported benchmark protocol.

## Not included

This public package does not redistribute CGSS2023 raw data, CGSS row-level derived tables, or raw seed-survey records. CGSS data remain subject to the original provider's access and redistribution terms. Users must obtain CGSS2023 through the official CGSS access channel and run the reconstruction scripts locally.

## Basic reproduction

1. Obtain authorized CGSS2023 data from the official provider.
2. Edit `examples/example_config.yaml` with the local data path.
3. Run `scripts/reconstruct_cgss2023.py` to generate aligned feature tables.
4. Run `scripts/build_mi_internal_3class.py` to construct internal three-class weak-empathy labels.
5. Run `scripts/evaluate_benchmark.py` and `scripts/train_tabnet.py` to reproduce baseline metrics.

## Citation

After DOI registration, replace the placeholder DOI in the paper and cite this archive with the DOI assigned by the repository.

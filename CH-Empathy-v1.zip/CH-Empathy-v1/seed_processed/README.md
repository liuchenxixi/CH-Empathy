# Seed Processed Data

Row-level seed-survey records are not included in this public package. The paper may report aggregate seed-set statistics, but public redistribution of individual records should only happen if participant consent and institutional ethics approval explicitly permit it.

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(__file__).resolve().parent / "data"
RESULT_DIR = Path(__file__).resolve().parent / "results_mi_internal_3class"
FEATURE_COLUMNS_PATH = PROJECT_ROOT / "process" / "data" / "new_schema" / "onehot_feature_columns.json"
INPUT_PATH = DATA_DIR / "cgss2023_onehot_mi_internal_3class.csv"


def load_data() -> tuple[np.ndarray, np.ndarray, list[str]]:
    feature_cols = json.loads(FEATURE_COLUMNS_PATH.read_text(encoding="utf-8"))
    df = pd.read_csv(INPUT_PATH)
    X = df[feature_cols].astype(np.float32).values
    y = pd.to_numeric(df["Empathy_Level_3"], errors="coerce").astype(int).values
    return X, y, feature_cols


def metrics_row(model_name: str, y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    return {
        "model": model_name,
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "precision_macro": float(precision_score(y_true, y_pred, average="macro", zero_division=0)),
        "recall_macro": float(recall_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
    }


def main() -> None:
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    X, y, _feature_cols = load_data()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    models = [
        ("majority", DummyClassifier(strategy="most_frequent")),
        ("stratified_dummy", DummyClassifier(strategy="stratified", random_state=42)),
        (
            "logistic_regression",
            make_pipeline(
                StandardScaler(with_mean=False),
                LogisticRegression(max_iter=2000, class_weight="balanced", random_state=42, n_jobs=-1),
            ),
        ),
        (
            "random_forest",
            RandomForestClassifier(
                n_estimators=500,
                max_depth=None,
                min_samples_leaf=2,
                class_weight="balanced_subsample",
                random_state=42,
                n_jobs=-1,
            ),
        ),
        (
            "hist_gradient_boosting",
            HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, l2_regularization=0.01, random_state=42),
        ),
        (
            "mlp",
            make_pipeline(
                StandardScaler(with_mean=False),
                MLPClassifier(hidden_layer_sizes=(128, 64), alpha=1e-4, learning_rate_init=1e-3, max_iter=300, random_state=42, early_stopping=True),
            ),
        ),
    ]

    rows = []
    predictions = pd.DataFrame({"y_true": y_test})
    for name, model in models:
        print(f"training {name}...")
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        predictions[name] = pred
        rows.append(metrics_row(name, y_test, pred))

    results = pd.DataFrame(rows).sort_values("macro_f1", ascending=False, kind="mergesort")
    results.to_csv(RESULT_DIR / "sklearn_mi_internal_3class_benchmarks.csv", index=False, encoding="utf-8-sig")
    predictions.to_csv(RESULT_DIR / "sklearn_mi_internal_3class_predictions.csv", index=False, encoding="utf-8-sig")

    print("\nBenchmark results:")
    print(results.to_string(index=False))
    print(f"\noutputs saved in: {RESULT_DIR}")


if __name__ == "__main__":
    main()

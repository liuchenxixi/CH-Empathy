
import os
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, mannwhitneyu, kruskal
from sklearn.linear_model import LinearRegression

ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
SOURCE = Path(os.environ.get("CGSS2023_DTA", PROJECT_ROOT / "data" / "CGSS2023.dta"))
if not SOURCE.exists():
    raise FileNotFoundError(
        "CGSS2023 raw data are not included in this release. "
        "Set CGSS2023_DTA=/path/to/CGSS2023.dta before running this script."
    )
OUT_DIR = PROJECT_ROOT / "results_construct_validity"
OUT_DIR.mkdir(exist_ok=True)
weak = pd.read_csv(PROJECT_ROOT / "data" / "CGSS2023_Pseudo_Labeled_mi_internal_3class.csv")

cols = [
    "a33", "a34", "b5", "b6", "c15d", "c15f", "c17a", "c17b", "c17c", "c17d", "c17e",
    "c17f", "c17g", "c17k", "c17l", "c17m", "c17n", "c17p", "c19", "b1810", "b1814",
    "c1c", "gender", "a2", "a3a", "a7a", "a8a",
]
avail = pd.read_stata(SOURCE, iterator=True).variable_labels().keys()
cols = [c for c in cols if c in avail]
raw = pd.read_stata(SOURCE, columns=cols, convert_categoricals=True)
raw.insert(0, "cgss2023_row_id", np.arange(len(raw)))
df = raw.merge(weak, on="cgss2023_row_id", how="inner")

def txt(v): return "nan" if pd.isna(v) else str(v).strip()
def agree5(v): return {"非常不同意":1,"比较不同意":2,"说不上同意不同意":3,"比较同意":4,"非常同意":5}.get(txt(v), np.nan)
def agree6(v): return {"非常不同意":1,"不同意":2,"有点不同意":3,"有点同意":4,"同意":5,"非常同意":6}.get(txt(v), np.nan)
def close5(v): return {"非常不密切":1,"不密切":2,"一般":3,"密切":4,"非常密切":5}.get(txt(v), np.nan)
def trust5(v): return {"非常不信任":1,"不信任":2,"一般":3,"信任":4,"非常信任":5}.get(txt(v), np.nan)
def trust4(v): return {"完全不信任":1,"不太信任":2,"比较信任":3,"非常信任":4}.get(txt(v), np.nan)
def majority4(v): return {"和大多数人打交道几乎总是需要非常小心":1,"和大多数人打交道通常需要非常小心":2,"大多数人通常是可以信任的":3,"大多数人几乎总是可以信任的":4}.get(txt(v), np.nan)
def bin_agree(v): return {"不同意":0,"同意":1}.get(txt(v), np.nan)
def gender(v):
    t=txt(v)
    return {"男":0,"女":1}.get(t, np.nan)
def age(v):
    try: return float(v)
    except Exception: return np.nan

def z(s):
    s = pd.Series(s, dtype=float)
    return (s - s.mean(skipna=True)) / s.std(skipna=True)

def comp(items, min_items=2):
    mat = pd.concat(items, axis=1)
    ok = mat.notna().sum(axis=1) >= min_items
    out = mat.mean(axis=1, skipna=True)
    out[~ok] = np.nan
    return out

# External variables not used in the 49-feature teacher schema.
vars_mapped = {}
vars_mapped["general_social_trust"] = df["a33"].map(agree5)
vars_mapped["low_exploitation_concern"] = df["a34"].map(lambda v: 6-agree5(v) if not np.isnan(agree5(v)) else np.nan) if "a34" in df else np.nan
vars_mapped["stranger_trust_b6"] = df["b6"].map(trust5)
vars_mapped["majority_trust_c19"] = df["c19"].map(majority4)
for c in ["c17a","c17b","c17c","c17d","c17e","c17f","c17g","c17k","c17l","c17m","c17n","c17p"]:
    if c in df:
        vars_mapped[c] = df[c].map(trust4)
vars_mapped["contact_relatives_friends"] = df["b5"].map(close5)
vars_mapped["neighbor_helpfulness"] = df["c15f"].map(agree6)
vars_mapped["contribute_to_society"] = df["c15d"].map(agree6)
if "c1c" in df:
    # Higher means active participation when categorical text matches common CGSS wording; leave unknown text as NaN.
    vars_mapped["public_welfare_participation"] = df["c1c"].map(lambda v: {"是":1,"否":0,"参加":1,"不参加":0}.get(txt(v), np.nan))
vars_mapped["income_fairness"] = df["b1810"].map(bin_agree)
vars_mapped["equal_opportunity"] = df["b1814"].map(bin_agree)

mapped = pd.DataFrame(vars_mapped)
# Standardized composites. Choose theory-driven groups, not post-hoc single best variables.
external = pd.DataFrame({
    "cgss2023_row_id": df["cgss2023_row_id"],
    "Empathy_Score_Pred": df["Empathy_Score_Pred"],
    "Empathy_Level_3": df["Empathy_Level_3"],
    "Empathy_Score_Uncertainty": df["Empathy_Score_Uncertainty"],
})
external["bridging_trust_index"] = comp([z(mapped[c]) for c in ["general_social_trust","low_exploitation_concern","stranger_trust_b6","majority_trust_c19","c17e"] if c in mapped], min_items=2)
external["interpersonal_trust_index"] = comp([z(mapped[c]) for c in ["c17a","c17b","c17c","c17d"] if c in mapped], min_items=2)
external["institutional_trust_index"] = comp([z(mapped[c]) for c in ["c17f","c17g","c17k","c17l","c17m","c17n","c17p"] if c in mapped], min_items=3)
external["social_connectedness_index"] = comp([z(mapped[c]) for c in ["contact_relatives_friends","neighbor_helpfulness","contribute_to_society"] if c in mapped], min_items=2)
external["fairness_index"] = comp([z(mapped[c]) for c in ["income_fairness","equal_opportunity"] if c in mapped], min_items=1)
external["positive_external_index"] = comp([external[c] for c in ["bridging_trust_index","interpersonal_trust_index","social_connectedness_index"]], min_items=2)

# Extreme groups based on weak score. This tests whether the released score ranks groups in expected directions.
q20_low = external["Empathy_Score_Pred"].quantile(0.20)
q20_high = external["Empathy_Score_Pred"].quantile(0.80)
q30_low = external["Empathy_Score_Pred"].quantile(0.30)
q30_high = external["Empathy_Score_Pred"].quantile(0.70)

def cohend(a,b):
    a=np.asarray(a, dtype=float); b=np.asarray(b, dtype=float)
    a=a[~np.isnan(a)]; b=b[~np.isnan(b)]
    if len(a)<2 or len(b)<2: return np.nan
    sp=np.sqrt(((len(a)-1)*a.var(ddof=1)+(len(b)-1)*b.var(ddof=1))/(len(a)+len(b)-2))
    return (b.mean()-a.mean())/sp if sp else np.nan

rows=[]
for name in ["bridging_trust_index","interpersonal_trust_index","institutional_trust_index","social_connectedness_index","fairness_index","positive_external_index"]:
    x=external[name]
    y=external["Empathy_Score_Pred"]
    valid=x.notna() & y.notna()
    rho,p=spearmanr(y[valid], x[valid]) if valid.sum()>30 else (np.nan,np.nan)
    means=[]; ns=[]; groups=[]
    for lv in [1,2,3]:
        vals=x[(external.Empathy_Level_3==lv)&x.notna()]
        means.append(vals.mean()); ns.append(len(vals)); groups.append(vals.values)
    kw_p=kruskal(*groups).pvalue if all(len(g)>0 for g in groups) else np.nan
    low20=x[(external.Empathy_Score_Pred<=q20_low)&x.notna()]
    high20=x[(external.Empathy_Score_Pred>=q20_high)&x.notna()]
    low30=x[(external.Empathy_Score_Pred<=q30_low)&x.notna()]
    high30=x[(external.Empathy_Score_Pred>=q30_high)&x.notna()]
    mw20=mannwhitneyu(low20, high20, alternative='two-sided').pvalue if len(low20)>0 and len(high20)>0 else np.nan
    rows.append({
        "index": name,
        "n": int(valid.sum()),
        "spearman_rho": rho,
        "spearman_p": p,
        "level1_mean": means[0], "level2_mean": means[1], "level3_mean": means[2],
        "level1_n": ns[0], "level2_n": ns[1], "level3_n": ns[2], "kruskal_p": kw_p,
        "top20_minus_bottom20": high20.mean()-low20.mean(),
        "top20_cohens_d": cohend(low20, high20),
        "top20_mwu_p": mw20,
        "top20_n_low": len(low20), "top20_n_high": len(high20),
        "top30_minus_bottom30": high30.mean()-low30.mean(),
        "top30_cohens_d": cohend(low30, high30),
    })
res=pd.DataFrame(rows).sort_values("top20_cohens_d", ascending=False)
external.to_csv(OUT_DIR/"external_construct_composite_scores.csv", index=False)
res.to_csv(OUT_DIR/"external_construct_composite_results.csv", index=False)
print("Saved:", OUT_DIR/"external_construct_composite_results.csv")
print(res.to_string(index=False, float_format=lambda v: f"{v:.4g}"))

# Simple demographic-adjusted residual check if raw demographics are available; use only approximate controls.
# This is supplementary and not required for the main claim.

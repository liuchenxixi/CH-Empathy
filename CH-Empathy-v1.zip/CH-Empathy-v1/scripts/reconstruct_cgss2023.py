from __future__ import annotations

import os
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=FutureWarning)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESS_SCHEMA_DIR = Path(__file__).resolve().parent
SOURCE_DATA = Path(os.environ.get("CGSS2023_DTA", PROJECT_ROOT / "data" / "CGSS2023.dta"))
OUT_DIR = PROJECT_ROOT / "data"

sys.path.append(str(PROCESS_SCHEMA_DIR))

from feature_schema import (  # noqa: E402
    SEMANTIC_FEATURES,
    UNKNOWN,
    align_onehot,
    apply_spouse_applicability,
    encode_onehot,
    finalize_semantic,
    first_existing,
    insurance_mean,
    load_feature_columns,
    map_age_group,
    map_area_cut,
    map_binary_yes_no,
    map_bmi_cut,
    map_child_cut,
    map_edu,
    map_edu_status,
    map_entertainment_frequency_7,
    map_frequency_5,
    map_frequency_9,
    map_gender,
    map_house_cut,
    map_hukou,
    map_hukou_loc,
    map_income_cut,
    map_marital,
    map_nationality,
    map_political,
    map_work_exper,
    public_service_cut,
    qcut_category,
    to_number,
    has_current_spouse,
)


CGSS2023_COLUMNS = [
    "a36", "a2", "a3a", "a4", "a5", "a6", "a7a", "a7b", "a8a", "a10", "a11",
    "a13", "a14", "a15", "a16", "a17", "a18", "a21", "a58", "a43a", "a43b",
    "a43c", "a43d", "a611", "a612", "a613", "a614", "a62", "a1", "a64", "a65",
    "a66", "a671", "a672", "a673", "a674", "a675", "a676", "a677", "a678", "a679",
    "a681", "a682", "a69", "a72", "a73", "a75a", "a81", "a89b", "a89c", "a90b",
    "a90c", "a281", "a282", "a283", "a284", "a285", "a3001", "a3002", "a3003",
    "a3004", "a3005", "a3006", "a3007", "a3008", "a3009", "a3010", "a3011",
    "a3012", "a311", "a312", "a313", "a31a", "a31b", "a35",
]


def ensure_out_dir() -> Path:
    if not SOURCE_DATA.exists():
        raise FileNotFoundError(
            "CGSS2023 raw data are not included in this release. "
            "Set CGSS2023_DTA=/path/to/CGSS2023.dta before running this script."
        )
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUT_DIR


def is_2023_unknown(value) -> bool:
    if pd.isna(value):
        return True
    text = str(value).strip()
    return text in {"", "nan", "NaN", "电话调查未调查", "不知道", "拒绝回答", "无法回答"}


def map_religion_2023(value):
    if is_2023_unknown(value):
        return UNKNOWN
    text = str(value).strip()
    if "不信仰宗教" in text:
        return 0
    return 1


def map_class_2023(value):
    if is_2023_unknown(value):
        return UNKNOWN
    number = to_number(value)
    if pd.notna(number) and 1 <= int(number) <= 10:
        return int(number)
    text = str(value).strip()
    if text.endswith("分"):
        number = pd.to_numeric(text[:-1], errors="coerce")
        if pd.notna(number) and 1 <= int(number) <= 10:
            return int(number)
    return UNKNOWN


def map_family_num_2023(value):
    number = to_number(value)
    if pd.isna(number):
        return np.nan
    return max(float(number) + 1.0, 1.0)


def map_media_frequency_2023(value):
    if is_2023_unknown(value):
        return np.nan
    text = str(value).strip()
    mapping = {
        "从不": 1,
        "很少": 2,
        "有时": 3,
        "经常": 4,
        "非常频繁": 5,
    }
    return mapping.get(text, np.nan)


def map_leisure_frequency_2023(value):
    if is_2023_unknown(value):
        return np.nan
    text = str(value).strip()
    mapping = {
        "从不": 1,
        "一年数次或更少": 2,
        "一月数次": 3,
        "一周数次": 4,
        "每天": 5,
    }
    return mapping.get(text, np.nan)


def qcut_sum_frequency(frame: pd.DataFrame, cols: list[str], mapper, q: int, labels: list[int]) -> pd.Series:
    if not cols:
        return pd.Series([UNKNOWN] * len(frame), index=frame.index)
    scores = frame[cols].apply(lambda col: col.map(mapper))
    valid_counts = scores.notna().sum(axis=1)
    cut = qcut_category(scores.sum(axis=1, min_count=1), q, labels)
    cut.loc[valid_counts == 0] = UNKNOWN
    return cut


def investment_series_2023(df: pd.DataFrame) -> pd.Series:
    invest_cols = [c for c in ["a672", "a673", "a674", "a675", "a676", "a677", "a678", "a679"] if c in df.columns]
    invest_any = df[invest_cols].apply(lambda col: col.map(map_binary_yes_no)).eq(1).any(axis=1) if invest_cols else False
    no_invest = first_existing(df, ["a671"]).apply(map_binary_yes_no)
    return pd.Series(np.where(invest_any, 1, np.where(no_invest == 1, 0, UNKNOWN)), index=df.index)


def build_cgss2023_semantic() -> pd.DataFrame:
    if not SOURCE_DATA.exists():
        raise FileNotFoundError(f"Missing CGSS2023 source file: {SOURCE_DATA}")

    available = pd.read_stata(SOURCE_DATA, iterator=True).variable_labels().keys()
    cols = [c for c in CGSS2023_COLUMNS if c in available]
    df = pd.read_stata(SOURCE_DATA, columns=cols, convert_categoricals=True)
    out = pd.DataFrame(index=df.index)

    out["happiness"] = first_existing(df, ["a36"]).apply(map_frequency_5)
    out["gender"] = first_existing(df, ["a2"]).apply(map_gender)
    out["age_group"] = first_existing(df, ["a3a"]).apply(map_age_group)
    out["nationality"] = first_existing(df, ["a4"]).apply(map_nationality)
    out["religion"] = first_existing(df, ["a5"]).apply(map_religion_2023)
    out["religion_freq"] = first_existing(df, ["a6"]).apply(map_frequency_9)

    out["bmi_cut"] = [
        map_bmi_cut(h, w)
        for h, w in zip(first_existing(df, ["a13"]), first_existing(df, ["a14"]))
    ]
    out["health"] = first_existing(df, ["a15"]).apply(map_frequency_5)
    out["health_problem"] = first_existing(df, ["a16"]).apply(map_frequency_5)
    out["depression"] = first_existing(df, ["a17"]).apply(map_frequency_5)
    out["edu_group"] = first_existing(df, ["a7a"]).apply(map_edu)
    out["edu_status"] = first_existing(df, ["a7b"]).apply(map_edu_status)
    out["political"] = first_existing(df, ["a10"]).apply(map_political)
    out["work_exper"] = first_existing(df, ["a58"]).apply(map_work_exper)
    out["hukou"] = first_existing(df, ["a18"]).apply(map_hukou)
    out["hukou_loc"] = first_existing(df, ["a21"]).apply(map_hukou_loc)

    out["income_cut"] = first_existing(df, ["a8a"]).apply(map_income_cut)
    out["family_income_cut"] = first_existing(df, ["a62"]).apply(map_income_cut)
    out["family_num"] = first_existing(df, ["a1"]).apply(map_family_num_2023).fillna(1).clip(lower=1)
    per_capita_area = pd.to_numeric(first_existing(df, ["a11"]), errors="coerce") / out["family_num"]
    out["floor_area_average_cut"] = per_capita_area.apply(map_area_cut)

    out["Class"] = first_existing(df, ["a43a"]).apply(map_class_2023)
    out["class_10_before"] = first_existing(df, ["a43b"]).apply(map_class_2023)
    out["class_10_after"] = first_existing(df, ["a43c"]).apply(map_class_2023)
    out["class_14"] = first_existing(df, ["a43d"]).apply(map_class_2023)
    out["car"] = first_existing(df, ["a66"]).apply(map_binary_yes_no)
    out["house_cut"] = first_existing(df, ["a65"]).apply(map_house_cut)
    out["insur_mean"] = insurance_mean(df, [c for c in ["a611", "a612", "a613", "a614"] if c in df.columns])
    out["family_status"] = first_existing(df, ["a64"]).apply(map_frequency_5)
    out["is_invest"] = investment_series_2023(df)

    out["marital"] = first_existing(df, ["a69"]).apply(map_marital)
    out["has_current_spouse"] = out["marital"].apply(has_current_spouse)
    out["s_political"] = first_existing(df, ["a73"]).apply(map_political)
    out["s_edu"] = first_existing(df, ["a72"]).apply(map_edu)
    out["s_income_cut"] = first_existing(df, ["a75a"]).apply(map_income_cut)
    out["s_work_exper"] = first_existing(df, ["a81"]).apply(map_work_exper)

    children = (
        pd.to_numeric(first_existing(df, ["a681"]), errors="coerce").fillna(0)
        + pd.to_numeric(first_existing(df, ["a682"]), errors="coerce").fillna(0)
    )
    out["child_cut"] = children.apply(map_child_cut)
    out["f_edu"] = first_existing(df, ["a89b"]).apply(map_edu)
    out["f_political"] = first_existing(df, ["a89c"]).apply(map_political)
    out["m_edu"] = first_existing(df, ["a90b"]).apply(map_edu)
    out["m_political"] = first_existing(df, ["a90c"]).apply(map_political)

    media_cols = [c for c in ["a281", "a282", "a283", "a284", "a285"] if c in df.columns]
    out["media_mean_cut"] = qcut_sum_frequency(df, media_cols, map_media_frequency_2023, 3, [1, 2, 3])
    leisure_cols = [c for c in [f"a30{i:02d}" for i in range(1, 13)] if c in df.columns]
    out["leisure_mean_cut"] = qcut_sum_frequency(df, leisure_cols, map_leisure_frequency_2023, 4, [1, 2, 3, 4])
    out["socialize"] = first_existing(df, ["a311"]).apply(map_frequency_5)
    out["relax"] = first_existing(df, ["a312"]).apply(map_frequency_5)
    out["learn"] = first_existing(df, ["a313"]).apply(map_frequency_5)
    out["entertain_neighbor"] = first_existing(df, ["a31a"]).apply(map_entertainment_frequency_7)
    out["entertain_friend"] = first_existing(df, ["a31b"]).apply(map_entertainment_frequency_7)
    out["equity"] = first_existing(df, ["a35"]).apply(map_frequency_5)

    # CGSS2023 does not include the four 2015 public-service satisfaction items b171-b174.
    out["public_service_cut"] = public_service_cut(df, [])

    out = apply_spouse_applicability(out)
    semantic = finalize_semantic(out[SEMANTIC_FEATURES], include_label=False)
    semantic.insert(0, "cgss2023_row_id", np.arange(len(semantic)))
    return semantic


def main() -> None:
    ensure_out_dir()
    semantic = build_cgss2023_semantic()
    semantic_path = OUT_DIR / "cgss2023_semantic.csv"
    semantic.to_csv(semantic_path, index=False, encoding="utf-8-sig")

    onehot = encode_onehot(semantic.drop(columns=["cgss2023_row_id"]), include_label=False)
    feature_columns = load_feature_columns(PROJECT_ROOT / "process" / "data" / "new_schema" / "onehot_feature_columns.json")
    onehot = align_onehot(onehot, feature_columns, include_label=False)
    onehot.insert(0, "cgss2023_row_id", semantic["cgss2023_row_id"].values)
    onehot_path = OUT_DIR / "cgss2023_onehot.csv"
    onehot.to_csv(onehot_path, index=False, encoding="utf-8-sig")

    print(f"cgss2023 semantic saved: {semantic_path} {semantic.shape}")
    print(f"cgss2023 onehot saved: {onehot_path} {onehot.shape}")


if __name__ == "__main__":
    main()

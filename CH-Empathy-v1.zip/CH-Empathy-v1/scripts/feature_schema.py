from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = DATA_DIR / "new_schema"

NO_SPOUSE = 98
UNKNOWN = 99


SEMANTIC_FEATURES = [
    "gender",
    "age_group",
    "happiness",
    "nationality",
    "religion",
    "religion_freq",
    "bmi_cut",
    "health",
    "health_problem",
    "depression",
    "edu_group",
    "edu_status",
    "political",
    "work_exper",
    "hukou",
    "hukou_loc",
    "income_cut",
    "floor_area_average_cut",
    "family_num",
    "Class",
    "class_10_before",
    "class_10_after",
    "class_14",
    "car",
    "house_cut",
    "family_income_cut",
    "insur_mean",
    "family_status",
    "is_invest",
    "marital",
    "has_current_spouse",
    "s_political",
    "s_edu",
    "s_income_cut",
    "s_work_exper",
    "child_cut",
    "f_edu",
    "f_political",
    "m_edu",
    "m_political",
    "media_mean_cut",
    "leisure_mean_cut",
    "socialize",
    "relax",
    "learn",
    "entertain_neighbor",
    "entertain_friend",
    "equity",
    "public_service_cut",
]

CONTINUOUS_FEATURES = ["family_num"]

CATEGORY_LEVELS = {
    "gender": [0, 1, UNKNOWN],
    "age_group": [1, 2, 3, 4, 5, UNKNOWN],
    "happiness": [1, 2, 3, 4, 5, UNKNOWN],
    "nationality": [1, 2, 3, 4, 5, 6, 7, 8, UNKNOWN],
    "religion": [0, 1, UNKNOWN],
    "religion_freq": [1, 2, 3, 4, 5, 6, 7, 8, 9, UNKNOWN],
    "bmi_cut": [0, 1, 2, UNKNOWN],
    "health": [1, 2, 3, 4, 5, UNKNOWN],
    "health_problem": [1, 2, 3, 4, 5, UNKNOWN],
    "depression": [1, 2, 3, 4, 5, UNKNOWN],
    "edu_group": [1, 2, 3, 4, 5, UNKNOWN],
    "edu_status": [1, 2, 3, 4, UNKNOWN],
    "political": [1, 2, 3, 4, UNKNOWN],
    "work_exper": [1, 2, UNKNOWN],
    "hukou": [1, 2, 3, 4, 5, 6, 7, 8, UNKNOWN],
    "hukou_loc": [1, 2, 3, 4, UNKNOWN],
    "income_cut": [0, 1, 2, 3, 4, 5, UNKNOWN],
    "floor_area_average_cut": [1, 2, 3, 4, 5, UNKNOWN],
    "Class": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, UNKNOWN],
    "class_10_before": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, UNKNOWN],
    "class_10_after": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, UNKNOWN],
    "class_14": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, UNKNOWN],
    "car": [0, 1, UNKNOWN],
    "house_cut": [0, 1, UNKNOWN],
    "family_income_cut": [0, 1, 2, 3, 4, 5, UNKNOWN],
    "insur_mean": [1.0, 1.25, 1.5, 1.75, 2.0, UNKNOWN],
    "family_status": [1, 2, 3, 4, 5, UNKNOWN],
    "is_invest": [0, 1, UNKNOWN],
    "marital": [1, 2, 3, 4, 5, 6, 7, UNKNOWN],
    "has_current_spouse": [0, 1, UNKNOWN],
    "s_political": [NO_SPOUSE, 1, 2, 3, 4, UNKNOWN],
    "s_edu": [NO_SPOUSE, 1, 2, 3, 4, 5, UNKNOWN],
    "s_income_cut": [NO_SPOUSE, 0, 1, 2, 3, 4, 5, UNKNOWN],
    "s_work_exper": [NO_SPOUSE, 1, 2, UNKNOWN],
    "child_cut": [1, 2, 3, 4, UNKNOWN],
    "f_edu": [1, 2, 3, 4, 5, UNKNOWN],
    "f_political": [1, 2, 3, 4, UNKNOWN],
    "m_edu": [1, 2, 3, 4, 5, UNKNOWN],
    "m_political": [1, 2, 3, 4, UNKNOWN],
    "media_mean_cut": [1, 2, 3, UNKNOWN],
    "leisure_mean_cut": [1, 2, 3, 4, UNKNOWN],
    "socialize": [1, 2, 3, 4, 5, UNKNOWN],
    "relax": [1, 2, 3, 4, 5, UNKNOWN],
    "learn": [1, 2, 3, 4, 5, UNKNOWN],
    "entertain_neighbor": [1, 2, 3, 4, 5, 6, 7, UNKNOWN],
    "entertain_friend": [1, 2, 3, 4, 5, 6, 7, UNKNOWN],
    "equity": [1, 2, 3, 4, 5, UNKNOWN],
    "public_service_cut": [1, 2, 3, 4, UNKNOWN],
}


IRI_ITEM_KEYWORDS = [
    "白日梦或幻想",
    "温柔、关切的感情",
    "别人的角度",
    "并不会同情遇到问题的人",
    "沉浸在小说人物",
    "紧急情况中，我会感到忧虑",
    "看电影或话剧时通常比较客观",
    "考虑所有人的立场",
    "看到有人被占便宜",
    "非常情绪化的情境",
    "朋友眼里的样子",
    "很少极其投入",
    "看到别人受伤",
    "别人的不幸通常不会",
    "不会浪费太多时间去听",
    "仿佛是其中的一个角色",
    "紧张的情绪情境",
    "不公平对待",
    "处理紧急情况时通常表现",
    "经常被我看到发生的事情所触动",
    "每个问题都有两面性",
    "心肠很软",
    "把自己代入主角",
    "紧急情况中，我容易失控",
    "站在他的立场",
    "有趣的故事或小说",
    "极度需要帮助的人",
    "批评别人之前",
]

IRI_REVERSE_INDICES = {2, 3, 6, 11, 12, 13, 14, 17, 18}


def ensure_out_dir() -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUT_DIR


def normalize_text(value) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip()


def contains_any(value, keywords: Iterable[str]) -> bool:
    text = normalize_text(value)
    return any(k in text for k in keywords)


def is_unknown(value) -> bool:
    text = normalize_text(value)
    if text == "":
        return True
    return contains_any(text, ["不知道", "不清楚", "无法回答", "拒绝", "缺失"])


def is_not_applicable(value) -> bool:
    return contains_any(value, ["不适用", "无配偶", "没有配偶", "从未结婚"])


def is_selected(value) -> bool:
    text = normalize_text(value)
    if text == "":
        return False
    if text.lower() in {"nan", "none", "0", "0.0", "否", "没有", "没有参加", "未参加"}:
        return False
    return True


def to_number(value):
    if is_unknown(value) or is_not_applicable(value):
        return np.nan
    return pd.to_numeric(value, errors="coerce")


def find_col(columns: Iterable[str], include: Iterable[str], exclude: Iterable[str] = ()) -> str:
    include = [include] if isinstance(include, str) else list(include)
    exclude = [exclude] if isinstance(exclude, str) else list(exclude)
    matches = [
        col for col in columns
        if all(k in col for k in include) and not any(k in col for k in exclude)
    ]
    if not matches:
        raise KeyError(f"未找到包含 {include} 且排除 {exclude} 的列")
    return matches[0]


def find_cols(columns: Iterable[str], include: Iterable[str], exclude: Iterable[str] = ()) -> list[str]:
    include = [include] if isinstance(include, str) else list(include)
    exclude = [exclude] if isinstance(exclude, str) else list(exclude)
    return [
        col for col in columns
        if all(k in col for k in include) and not any(k in col for k in exclude)
    ]


def first_existing(df: pd.DataFrame, names: Iterable[str]):
    for name in names:
        if name in df.columns:
            return df[name]
    return pd.Series([np.nan] * len(df), index=df.index)


def constant_unknown(index) -> pd.Series:
    return pd.Series([UNKNOWN] * len(index), index=index)


def one_to_five(value):
    if is_unknown(value):
        return UNKNOWN
    number = to_number(value)
    if pd.notna(number) and 1 <= number <= 5:
        return int(number)
    text = normalize_text(value)
    ordered = [
        ["非常不", "很不", "远低", "完全不", "从不"],
        ["比较不", "不太", "低于", "很少"],
        ["一般", "说不上", "平均", "有时"],
        ["比较", "高于", "经常"],
        ["非常", "远高", "完全", "总是", "很好", "很健康"],
    ]
    for i, keys in enumerate(ordered, start=1):
        if contains_any(text, keys):
            return i
    return UNKNOWN


def map_gender(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    if "男" in text or text in {"1", "1.0"}:
        return 1
    if "女" in text or text in {"0", "0.0", "2", "2.0"}:
        return 0
    return UNKNOWN


def map_age_group(value, current_year: int = 2026):
    year = to_number(value)
    if pd.isna(year):
        return UNKNOWN
    age = current_year - int(year)
    if age <= 18:
        return 1
    if age <= 28:
        return 2
    if age <= 44:
        return 3
    if age <= 60:
        return 4
    if age <= 120:
        return 5
    return UNKNOWN


def map_nationality(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    if "汉" in text or text in {"1", "1.0"}:
        return 1
    if "蒙古" in text or text in {"2", "2.0"}:
        return 2
    if "满" in text or text in {"3", "3.0"}:
        return 3
    if "回" in text or text in {"4", "4.0"}:
        return 4
    if "藏" in text or text in {"5", "5.0"}:
        return 5
    if "壮" in text or text in {"6", "6.0"}:
        return 6
    if "维" in text or text in {"7", "7.0"}:
        return 7
    return 8


def map_edu(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    if is_not_applicable(text):
        return NO_SPOUSE
    number = to_number(value)
    if pd.notna(number):
        n = int(number)
        if n in {1, 2, 3, 4}:
            return 1
        if n in {5, 6, 7, 8}:
            return 2
        if n in {9, 10}:
            return 3
        if n in {11, 12}:
            return 4
        if n >= 13:
            return 5
    if contains_any(text, ["没有", "私塾", "扫盲", "小学", "初中"]):
        return 1
    if contains_any(text, ["高中", "中专", "技校", "职业"]):
        return 2
    if "专科" in text:
        return 3
    if "本科" in text:
        return 4
    if contains_any(text, ["研究生", "硕士", "博士"]):
        return 5
    return UNKNOWN


def map_edu_status(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    number = to_number(value)
    if pd.notna(number) and int(number) in {1, 2, 3, 4}:
        return int(number)
    if contains_any(text, ["正在读", "全日制"]):
        return 1
    if "非全日制" in text:
        return 2
    if contains_any(text, ["毕业", "完成"]):
        return 4
    if contains_any(text, ["辍学", "肄业", "中途"]):
        return 3
    return UNKNOWN


def map_political(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    if is_not_applicable(text):
        return NO_SPOUSE
    number = to_number(value)
    if pd.notna(number) and int(number) in {1, 2, 3, 4}:
        return int(number)
    if "群众" in text:
        return 1
    if "共青团" in text:
        return 2
    if "民主党派" in text:
        return 3
    if "共产党" in text or "中共" in text or "党员" in text:
        return 4
    return UNKNOWN


def map_hukou(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    number = to_number(value)
    if pd.notna(number) and 1 <= int(number) <= 8:
        return int(number)
    if "农业" in text:
        return 1
    if "非农业" in text:
        return 2
    if "蓝印" in text:
        return 3
    if "居民" in text and "农业" in text:
        return 4
    if "居民" in text and "非农业" in text:
        return 5
    if "军" in text:
        return 6
    if "没有户口" in text:
        return 7
    return 8


def map_hukou_loc(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    number = to_number(value)
    if pd.notna(number) and 1 <= int(number) <= 4:
        return int(number)
    if contains_any(text, ["本乡", "本镇", "本街道"]):
        return 1
    if contains_any(text, ["本县", "本区"]):
        return 2
    if contains_any(text, ["本市", "本省", "县级市以外"]):
        return 3
    return 4


def map_income_cut(value):
    if is_unknown(value):
        return UNKNOWN
    if is_not_applicable(value):
        return UNKNOWN
    val = to_number(value)
    if pd.isna(val):
        return UNKNOWN
    if 1 <= val <= 6 and float(val).is_integer():
        return int(val) - 1
    if val <= 10:
        return 0
    if val <= 50000:
        return 1
    if val <= 100000:
        return 2
    if val <= 150000:
        return 3
    if val <= 300000:
        return 4
    return 5


def map_area_cut(value):
    val = to_number(value)
    if pd.isna(val) or val <= 0:
        return UNKNOWN
    if val <= 30:
        return 1
    if val <= 70:
        return 2
    if val <= 110:
        return 3
    if val <= 150:
        return 4
    return 5


def map_bmi_cut(height, weight):
    h = to_number(height)
    w = to_number(weight)
    if pd.isna(h) or pd.isna(w) or h <= 0 or w <= 0:
        return UNKNOWN
    if h > 3:
        h = h / 100.0
    # Seed questionnaires and CGSS a14 both record weight in jin.
    w = w / 2.0
    bmi = w / (h ** 2)
    if bmi < 18.5:
        return 0
    if bmi < 24:
        return 1
    return 2


def map_binary_yes_no(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    number = to_number(value)
    if pd.notna(number):
        if number in {0, 2}:
            return 0
        if number == 1:
            return 1
    if contains_any(text, ["没有", "否", "未", "不"]):
        return 0
    if contains_any(text, ["有", "是", "参加", "从事"]):
        return 1
    return UNKNOWN


def map_house_cut(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    number = to_number(value)
    if pd.notna(number):
        return 1 if number > 0 else 0
    return map_binary_yes_no(value)


def map_class(value):
    val = to_number(value)
    if pd.notna(val) and 1 <= int(val) <= 10:
        return int(val)
    text = normalize_text(value)
    if text.startswith("1("):
        return 1
    if text.startswith("10("):
        return 10
    return UNKNOWN


def map_marital(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    number = to_number(value)
    if pd.notna(number) and 1 <= int(number) <= 7:
        return int(number)
    if "未婚" in text:
        return 1
    if "同居" in text:
        return 2
    if "初婚" in text:
        return 3
    if "再婚" in text:
        return 4
    if "分居" in text:
        return 5
    if "离婚" in text:
        return 6
    if "丧偶" in text:
        return 7
    return UNKNOWN


def has_current_spouse(marital):
    if marital in {2, 3, 4, 5}:
        return 1
    if marital in {1, 6, 7}:
        return 0
    return UNKNOWN


def map_work_status(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    if is_not_applicable(text):
        return NO_SPOUSE
    number = to_number(value)
    if pd.notna(number):
        return 1 if int(number) == 1 else 2
    if contains_any(text, ["没有工作", "无工作", "退休", "失业", "未工作"]):
        return 2
    return 1


def map_work_exper(value):
    text = normalize_text(value)
    if is_unknown(text):
        return UNKNOWN
    if is_not_applicable(text):
        return NO_SPOUSE
    number = to_number(value)
    if pd.notna(number):
        n = int(number)
        if n in {1, 4, 6}:
            return 1
        if n in {2, 3, 5}:
            return 2
    if contains_any(text, ["目前从事", "目前务农", "在业", "有工作"]):
        return 1
    if contains_any(text, ["目前没有工作", "从未工作", "无工作", "没有工作", "不在业", "未工作", "失业", "退休"]):
        return 2
    return UNKNOWN


def map_child_cut(value):
    val = to_number(value)
    if pd.isna(val):
        return UNKNOWN
    if val <= 0:
        return 1
    if val == 1:
        return 2
    if val == 2:
        return 3
    return 4


def map_frequency_5(value):
    val = to_number(value)
    if pd.notna(val) and 1 <= int(val) <= 5:
        return int(val)
    return one_to_five(value)


def map_entertainment_frequency_7(value):
    if is_unknown(value):
        return UNKNOWN
    val = to_number(value)
    if pd.notna(val) and 1 <= int(val) <= 7:
        return int(val)
    text = normalize_text(value)
    if contains_any(text, ["几乎每天"]):
        return 1
    if contains_any(text, ["一周1到2次", "一周一到两次", "每周一到两次"]):
        return 2
    if contains_any(text, ["一个月几次"]):
        return 3
    if contains_any(text, ["大约一个月1次", "大约一个月一次"]):
        return 4
    if contains_any(text, ["一年几次"]):
        return 5
    if contains_any(text, ["一年1次或更少", "一年一次或更少"]):
        return 6
    if contains_any(text, ["从来不"]):
        return 7
    return UNKNOWN


def map_frequency_9(value):
    if is_unknown(value):
        return UNKNOWN
    val = to_number(value)
    if pd.notna(val) and 1 <= int(val) <= 9:
        return int(val)
    text = normalize_text(value)
    if contains_any(text, ["从来没有参加过"]):
        return 1
    if contains_any(text, ["一年不到1次"]):
        return 2
    if contains_any(text, ["一年大概1到2次"]):
        return 3
    if contains_any(text, ["一年几次"]):
        return 4
    if contains_any(text, ["大概一月1次"]):
        return 5
    if contains_any(text, ["一月2到3次"]):
        return 6
    if contains_any(text, ["差不多每周都有"]):
        return 7
    if contains_any(text, ["每周都有"]):
        return 8
    if contains_any(text, ["一周几次"]):
        return 9
    levels = [
        ["从来", "从未"],
        ["一年不到"],
        ["一年大概", "一到两次"],
        ["一年几次"],
        ["一月一次"],
        ["一月两", "一个月两"],
        ["每周"],
        ["每周都有"],
        ["一周几次"],
    ]
    for i, keys in enumerate(levels, start=1):
        if contains_any(text, keys):
            return i
    return UNKNOWN


def qcut_category(series: pd.Series, q: int, labels: list[int]) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    result = pd.Series([UNKNOWN] * len(numeric), index=numeric.index)
    valid = numeric.dropna()
    if valid.empty:
        return result
    if valid.nunique() <= 1:
        result.loc[valid.index] = labels[0]
        return result
    codes = pd.qcut(valid, q=q, labels=False, duplicates="drop")
    result.loc[codes.index] = codes.map(lambda x: labels[int(x)])
    return result


def map_public_service_value(value):
    if is_unknown(value):
        return np.nan
    number = to_number(value)
    if pd.notna(number) and 1 <= number <= 5:
        return float(number)
    text = normalize_text(value)
    if contains_any(text, ["非常不满意", "闈炲父涓嶆弧鎰?"]):
        return 1.0
    if contains_any(text, ["不太满意", "涓嶅お婊℃剰"]):
        return 2.0
    if contains_any(text, ["说不清满意不满意", "璇翠笉娓呮弧鎰忎笉婊℃剰"]):
        return 3.0
    if contains_any(text, ["比较满意", "姣旇緝婊℃剰"]):
        return 4.0
    if contains_any(text, ["非常满意", "闈炲父婊℃剰"]):
        return 5.0
    return np.nan


def public_service_cut(frame: pd.DataFrame, cols: list[str]) -> pd.Series:
    if not cols:
        return pd.Series([UNKNOWN] * len(frame), index=frame.index)
    scores = frame[cols].applymap(map_public_service_value)
    valid_counts = scores.notna().sum(axis=1)
    summed = scores.sum(axis=1, min_count=1)
    cut = qcut_category(summed, 4, [1, 2, 3, 4])
    cut.loc[valid_counts == 0] = UNKNOWN
    return cut


def insurance_mean(frame: pd.DataFrame, cols: list[str]) -> pd.Series:
    values = []
    for col in cols:
        mapped = frame[col].apply(lambda x: 1.0 if map_binary_yes_no(x) == 1 else 2.0 if map_binary_yes_no(x) == 0 else np.nan)
        values.append(mapped)
    if not values:
        return pd.Series([UNKNOWN] * len(frame), index=frame.index)
    mat = pd.concat(values, axis=1)
    mean = mat.mean(axis=1)
    mean.loc[mat.notna().sum(axis=1) < len(cols)] = UNKNOWN
    return mean.fillna(UNKNOWN)


def apply_spouse_applicability(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    no_spouse = out["has_current_spouse"] == 0
    unknown_spouse = out["has_current_spouse"] == UNKNOWN
    spouse_cols = ["s_political", "s_edu", "s_income_cut", "s_work_exper"]
    for col in spouse_cols:
        out[col] = out[col].astype("object")
        out.loc[no_spouse, col] = NO_SPOUSE
        out.loc[unknown_spouse & out[col].isna(), col] = UNKNOWN
    return out


def finalize_semantic(df: pd.DataFrame, include_label: bool) -> pd.DataFrame:
    out = df.copy()
    for col in SEMANTIC_FEATURES:
        if col not in out.columns:
            out[col] = UNKNOWN
    out = out[SEMANTIC_FEATURES + (["Empathy_Level"] if include_label else [])]
    for col in SEMANTIC_FEATURES:
        if col in CONTINUOUS_FEATURES:
            out[col] = pd.to_numeric(out[col], errors="coerce").fillna(out[col].median())
            if out[col].isna().any():
                out[col] = out[col].fillna(0)
        else:
            out[col] = out[col].astype("object")
            out[col] = out[col].fillna(UNKNOWN)
            out[col] = pd.Categorical(out[col], categories=CATEGORY_LEVELS[col])
    if include_label:
        out["Empathy_Level"] = pd.to_numeric(out["Empathy_Level"], errors="coerce").astype("Int64")
    return out


def encode_onehot(df: pd.DataFrame, include_label: bool) -> pd.DataFrame:
    label = None
    features = df.copy()
    if include_label:
        label = features.pop("Empathy_Level")
    features = finalize_semantic(features, include_label=False)
    categorical_cols = [c for c in SEMANTIC_FEATURES if c not in CONTINUOUS_FEATURES]
    encoded = pd.get_dummies(features, columns=categorical_cols, drop_first=False, dtype=int)
    if include_label:
        encoded["Empathy_Level"] = label.values
    return encoded


def save_feature_columns(columns: Iterable[str], path: Path | None = None) -> Path:
    path = path or ensure_out_dir() / "onehot_feature_columns.json"
    feature_cols = [c for c in columns if c != "Empathy_Level"]
    path.write_text(json.dumps(feature_cols, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def load_feature_columns(path: Path | None = None) -> list[str]:
    path = path or ensure_out_dir() / "onehot_feature_columns.json"
    return json.loads(path.read_text(encoding="utf-8"))


def align_onehot(df: pd.DataFrame, columns: list[str], include_label: bool) -> pd.DataFrame:
    out = df.copy()
    label = None
    if include_label and "Empathy_Level" in out.columns:
        label = out.pop("Empathy_Level")
    out = out.reindex(columns=columns, fill_value=0)
    if include_label and label is not None:
        out["Empathy_Level"] = label.values
    return out

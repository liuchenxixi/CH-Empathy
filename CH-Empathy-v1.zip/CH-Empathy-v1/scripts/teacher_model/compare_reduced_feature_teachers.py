from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.feature_selection import SelectKBest, mutual_info_classif, mutual_info_regression
from sklearn.impute import SimpleImputer
from sklearn.linear_model import ElasticNet, LogisticRegression, Ridge
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
)
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVR

from shared import (
    OUT_DIR,
    apply_bins,
    feature_columns,
    load_seed_onehot,
    load_seed_scores,
    quantile_bins,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROCESS_SCHEMA_DIR = PROJECT_ROOT / "process" / "new_schema"
PROCESS_DATA_DIR = PROJECT_ROOT / "process" / "data" / "new_schema"

sys.path.append(str(PROCESS_SCHEMA_DIR))
from feature_schema import NO_SPOUSE, SEMANTIC_FEATURES, UNKNOWN  # noqa: E402


RANDOM_STATE = 42


DOMAIN_GROUPS = {
    "demographic": ["gender", "age_group", "nationality"],
    "wellbeing_health": ["happiness", "bmi_cut", "health", "health_problem", "depression"],
    "education_work": ["edu_group", "edu_status", "political", "work_exper"],
    "hukou_resource": [
        "hukou",
        "hukou_loc",
        "income_cut",
        "family_income_cut",
        "floor_area_average_cut",
        "house_cut",
        "car",
        "is_invest",
        "insur_mean",
    ],
    "class_mobility": ["Class", "class_10_before", "class_10_after", "class_14"],
    "family_marriage": ["family_num", "family_status", "marital", "has_current_spouse", "child_cut"],
    "spouse": ["s_political", "s_edu", "s_income_cut", "s_work_exper"],
    "parents": ["f_edu", "f_political", "m_edu", "m_political"],
    "media_leisure": [
        "media_mean_cut",
        "leisure_mean_cut",
        "socialize",
        "relax",
        "learn",
        "entertain_neighbor",
        "entertain_friend",
    ],
    "belief_public": ["religion", "religion_freq", "equity", "public_service_cut"],
}


@dataclass(frozen=True)
class DatasetSpec:
    name: str
    X: pd.DataFrame
    kind: str


class OrdinalLogit3(BaseEstimator, ClassifierMixin):
    """Three-class ordinal classifier from two cumulative logistic models."""

    def __init__(self, C: float = 1.0, max_iter: int = 2000):
        self.C = C
        self.max_iter = max_iter

    def fit(self, X, y):
        y = np.asarray(y).astype(int)
        self.classes_ = np.array([1, 2, 3])
        self.lower_model_ = LogisticRegression(
            C=self.C, class_weight="balanced", max_iter=self.max_iter, solver="liblinear"
        ).fit(X, (y >= 2).astype(int))
        self.upper_model_ = LogisticRegression(
            C=self.C, class_weight="balanced", max_iter=self.max_iter, solver="liblinear"
        ).fit(X, (y >= 3).astype(int))
        return self

    def predict_proba(self, X):
        p_ge2 = self.lower_model_.predict_proba(X)[:, 1]
        p_ge3 = self.upper_model_.predict_proba(X)[:, 1]
        p_ge3 = np.minimum(p_ge3, p_ge2)
        probs = np.column_stack([1.0 - p_ge2, p_ge2 - p_ge3, p_ge3])
        probs = np.clip(probs, 0.0, 1.0)
        row_sum = probs.sum(axis=1, keepdims=True)
        return probs / np.where(row_sum == 0, 1.0, row_sum)

    def predict(self, X):
        return self.classes_[np.argmax(self.predict_proba(X), axis=1)]


def load_seed_semantic(y_score: pd.Series) -> pd.DataFrame:
    seed_path = PROCESS_DATA_DIR / "seed_semantic.csv"
    if not seed_path.exists():
        raise FileNotFoundError(f"Missing seed semantic file: {seed_path}")
    seed = pd.read_csv(seed_path)
    missing = [col for col in SEMANTIC_FEATURES if col not in seed.columns]
    if missing:
        raise ValueError(f"seed_semantic.csv is missing semantic columns: {missing[:10]}")
    valid = pd.to_numeric(seed["Empathy_Level"], errors="coerce").notna() & y_score.notna()
    return seed.loc[valid, SEMANTIC_FEATURES].reset_index(drop=True)


def semantic_numeric(seed_semantic: pd.DataFrame) -> pd.DataFrame:
    X = seed_semantic.copy()
    for col in X.columns:
        X[col] = pd.to_numeric(X[col], errors="coerce")
    missing = X.isna() | X.eq(UNKNOWN)
    X = X.mask(X.eq(UNKNOWN), np.nan)
    spouse_cols = [col for col in X.columns if col.startswith("s_")]
    X[spouse_cols] = X[spouse_cols].mask(X[spouse_cols].eq(NO_SPOUSE), np.nan)
    for col in list(X.columns):
        X[f"{col}_missing"] = missing[col].astype(int)
    return X


def domain_aggregates(seed_semantic: pd.DataFrame) -> pd.DataFrame:
    X_num = semantic_numeric(seed_semantic)
    base_cols = [col for col in SEMANTIC_FEATURES if col in X_num.columns]
    values = X_num[base_cols]
    medians = values.median(axis=0, skipna=True)
    filled = values.fillna(medians).fillna(0.0)
    std = filled.std(axis=0).replace(0, 1.0)
    z = (filled - filled.mean(axis=0)) / std

    out = pd.DataFrame(index=seed_semantic.index)
    for group_name, cols in DOMAIN_GROUPS.items():
        group_cols = [col for col in cols if col in z.columns]
        out[f"{group_name}_mean"] = z[group_cols].mean(axis=1)
        out[f"{group_name}_missing_rate"] = values[group_cols].isna().mean(axis=1)
    return out.reset_index(drop=True)


def classifier_pipeline(model, *, select_k: int | None = None) -> Pipeline:
    steps = [("imputer", SimpleImputer(strategy="most_frequent"))]
    if select_k is not None:
        steps.append(("select", SelectKBest(mutual_info_classif, k=select_k)))
    steps.extend([("scaler", StandardScaler()), ("model", model)])
    return Pipeline(steps)


def regressor_pipeline(model, *, select_k: int | None = None, scale: bool = True) -> Pipeline:
    steps = [("imputer", SimpleImputer(strategy="median"))]
    if select_k is not None:
        steps.append(("select", SelectKBest(mutual_info_regression, k=select_k)))
    if scale:
        steps.append(("scaler", StandardScaler()))
    steps.append(("model", model))
    return Pipeline(steps)


def safe_corr(fn, y_true, y_pred) -> float:
    if np.std(y_pred) == 0 or np.std(y_true) == 0:
        return np.nan
    return float(fn(y_true, y_pred).statistic)


def score_row(dataset: str, model: str, task: str, y_score, y_true_3, pred_score, pred_3) -> dict:
    row = {
        "dataset": dataset,
        "model": model,
        "task": task,
        "accuracy_3": accuracy_score(y_true_3, pred_3),
        "balanced_accuracy_3": balanced_accuracy_score(y_true_3, pred_3),
        "macro_f1_3": f1_score(y_true_3, pred_3, average="macro"),
    }
    if pred_score is None:
        row.update({"mae": np.nan, "rmse": np.nan, "pearson_r": np.nan, "spearman_rho": np.nan})
    else:
        row.update(
            {
                "mae": mean_absolute_error(y_score, pred_score),
                "rmse": mean_squared_error(y_score, pred_score, squared=False),
                "pearson_r": safe_corr(pearsonr, y_score, pred_score),
                "spearman_rho": safe_corr(spearmanr, y_score, pred_score),
            }
        )
    return row


def evaluate_dataset(spec: DatasetSpec, y_score: pd.Series, y_3: np.ndarray, bins_3: np.ndarray) -> list[dict]:
    n_features = spec.X.shape[1]
    select_k = min(80, n_features)
    regressors = {
        "ridge": regressor_pipeline(Ridge(alpha=10.0)),
        "elastic_net": regressor_pipeline(ElasticNet(alpha=0.05, l1_ratio=0.2, max_iter=10000)),
        "linear_svr": regressor_pipeline(LinearSVR(C=0.5, epsilon=0.5, random_state=RANDOM_STATE, max_iter=20000)),
        "hgb_regressor": regressor_pipeline(
            HistGradientBoostingRegressor(max_iter=200, learning_rate=0.04, l2_regularization=1.0, random_state=RANDOM_STATE),
            scale=False,
        ),
        "random_forest": regressor_pipeline(
            RandomForestRegressor(
                n_estimators=300,
                max_depth=8,
                min_samples_leaf=5,
                max_features="sqrt",
                random_state=RANDOM_STATE,
                n_jobs=-1,
            ),
            scale=False,
        ),
        "extra_trees": regressor_pipeline(
            ExtraTreesRegressor(
                n_estimators=300,
                max_depth=8,
                min_samples_leaf=5,
                max_features="sqrt",
                random_state=RANDOM_STATE,
                n_jobs=-1,
            ),
            scale=False,
        ),
    }
    classifiers = {
        "majority": DummyClassifier(strategy="most_frequent"),
        "logistic_balanced": classifier_pipeline(LogisticRegression(max_iter=3000, class_weight="balanced", C=0.3)),
        "ordinal_logit": classifier_pipeline(OrdinalLogit3(C=0.3)),
    }
    if spec.name == "onehot_full":
        regressors = {
            f"{name}_mi{select_k}": regressor_pipeline(pipe.named_steps["model"], select_k=select_k, scale=("scaler" in pipe.named_steps))
            for name, pipe in regressors.items()
        }
        classifiers = {
            f"{name}_mi{select_k}": classifier_pipeline(pipe.named_steps["model"], select_k=select_k)
            if name != "majority"
            else pipe
            for name, pipe in classifiers.items()
        }

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    rows = []
    X = spec.X.reset_index(drop=True)
    y_score_np = y_score.to_numpy(dtype=float)
    y_3_np = np.asarray(y_3, dtype=int)

    for model_name, model in regressors.items():
        pred_score = np.zeros(len(X), dtype=float)
        for train_idx, test_idx in cv.split(X, y_3_np):
            fitted = clone(model).fit(X.iloc[train_idx], y_score_np[train_idx])
            pred_score[test_idx] = fitted.predict(X.iloc[test_idx])
        pred_3 = np.asarray(apply_bins(pred_score, bins_3), dtype=int)
        rows.append(score_row(spec.name, model_name, "score_regression", y_score_np, y_3_np, pred_score, pred_3))

    for model_name, model in classifiers.items():
        pred_3 = np.zeros(len(X), dtype=int)
        for train_idx, test_idx in cv.split(X, y_3_np):
            fitted = clone(model).fit(X.iloc[train_idx], y_3_np[train_idx])
            pred_3[test_idx] = fitted.predict(X.iloc[test_idx])
        rows.append(score_row(spec.name, model_name, "direct_3class", y_score_np, y_3_np, None, pred_3))
    return rows


def main() -> None:
    X_onehot, _, y_score, _features = load_seed_onehot()
    y_score_full = load_seed_scores()
    seed_sem = load_seed_semantic(y_score_full)

    bins_3 = quantile_bins(y_score, 3)
    y_3 = np.asarray(apply_bins(y_score, bins_3), dtype=int)

    X_semantic = semantic_numeric(seed_sem)
    X_domain = domain_aggregates(seed_sem)
    X_semantic_domain = pd.concat([X_semantic, X_domain], axis=1)

    specs = [
        DatasetSpec("onehot_full", X_onehot, "onehot"),
        DatasetSpec("semantic_numeric", X_semantic, "manual_reduced"),
        DatasetSpec("domain_aggregated", X_domain, "manual_reduced"),
        DatasetSpec("semantic_plus_domain", X_semantic_domain, "manual_reduced"),
    ]

    rows = []
    for spec in specs:
        print(f"Evaluating {spec.name}: {spec.X.shape[1]} features")
        rows.extend(evaluate_dataset(spec, y_score, y_3, bins_3))

    out_dir = OUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    results = pd.DataFrame(rows).sort_values(
        ["macro_f1_3", "spearman_rho", "mae"], ascending=[False, False, True], na_position="last"
    )
    out_path = out_dir / "reduced_feature_teacher_comparison.csv"
    results.to_csv(out_path, index=False)

    print("\nTop models by three-level macro-F1:")
    print(
        results[
            [
                "dataset",
                "model",
                "task",
                "macro_f1_3",
                "balanced_accuracy_3",
                "mae",
                "rmse",
                "spearman_rho",
                "pearson_r",
            ]
        ]
        .head(15)
        .to_string(index=False)
    )
    print(f"\nSaved: {out_path}")


if __name__ == "__main__":
    main()

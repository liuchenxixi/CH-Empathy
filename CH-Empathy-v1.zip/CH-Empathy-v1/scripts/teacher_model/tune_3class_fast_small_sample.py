
from __future__ import annotations

import itertools
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, RidgeClassifier, SGDClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.svm import LinearSVC, SVC

from compare_reduced_feature_teachers import DOMAIN_GROUPS, domain_aggregates, load_seed_semantic, semantic_numeric
from shared import OUT_DIR, apply_bins, load_seed_onehot, load_seed_scores, quantile_bins

warnings.filterwarnings("ignore")
RANDOM_STATE = 42


class ProbabilityThresholdClassifier(BaseEstimator, ClassifierMixin):
    def __init__(self, base_estimator=None, grid_size=31):
        self.base_estimator = base_estimator
        self.grid_size = grid_size

    def fit(self, X, y):
        self.classes_ = np.array([0, 1, 2])
        self.model_ = clone(self.base_estimator).fit(X, y)
        proba = self.model_.predict_proba(X)
        self.thresholds_ = self._best_thresholds(proba, y)
        return self

    def _best_thresholds(self, proba, y):
        best = (-1, 0.34, 0.34)
        grid = np.linspace(0.18, 0.65, self.grid_size)
        for t0, t2 in itertools.product(grid, grid):
            pred = proba.argmax(axis=1)
            pred[proba[:, 0] >= t0] = 0
            pred[proba[:, 2] >= t2] = 2
            score = f1_score(y, pred, average="macro")
            if score > best[0]:
                best = (score, float(t0), float(t2))
        return best[1], best[2]

    def predict(self, X):
        proba = self.model_.predict_proba(X)
        pred = proba.argmax(axis=1)
        t0, t2 = self.thresholds_
        pred[proba[:, 0] >= t0] = 0
        pred[proba[:, 2] >= t2] = 2
        return pred


def make_pipeline(model, selector="none", poly=False):
    steps = [("imputer", SimpleImputer(strategy="median"))]
    if selector.startswith("mi"):
        steps.append(("select", SelectKBest(mutual_info_classif, k=int(selector[2:]))))
    elif selector.startswith("f"):
        steps.append(("select", SelectKBest(f_classif, k=int(selector[1:]))))
    steps.append(("scaler", StandardScaler()))
    if poly:
        steps.append(("poly", PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)))
    steps.append(("model", model))
    return Pipeline(steps)


def build_datasets():
    _, _, y_score, _ = load_seed_onehot()
    seed_sem = load_seed_semantic(load_seed_scores())
    X_sem = semantic_numeric(seed_sem)
    X_domain = domain_aggregates(seed_sem)
    X_plus = pd.concat([X_sem, X_domain], axis=1)
    datasets = {
        "semantic_numeric": X_sem,
        "semantic_plus_domain": X_plus,
        "domain_aggregated": X_domain,
    }
    for group, cols in DOMAIN_GROUPS.items():
        drop = set(cols + [f"{c}_missing" for c in cols])
        keep = [c for c in X_sem.columns if c not in drop]
        datasets[f"semantic_no_{group}"] = X_sem[keep]
    for groups in [
        ("no_spouse_parents", ["spouse", "parents"]),
        ("no_demo_spouse_parents", ["demographic", "spouse", "parents"]),
        ("core_social", ["wellbeing_health", "education_work", "hukou_resource", "class_mobility", "family_marriage", "media_leisure", "belief_public"]),
    ]:
        name, gs = groups
        cols = []
        for g in gs:
            cols.extend(DOMAIN_GROUPS[g])
        cols = [c for c in cols if c in X_sem.columns]
        cols += [f"{c}_missing" for c in cols if f"{c}_missing" in X_sem.columns]
        if name.startswith("no_"):
            drop = set(cols)
            keep = [c for c in X_sem.columns if c not in drop]
            datasets[f"semantic_{name}"] = X_sem[keep]
        else:
            datasets[f"semantic_{name}"] = X_sem[cols]
    y = np.asarray(apply_bins(y_score, quantile_bins(y_score, 3)), dtype=int) - 1
    return datasets, y_score.to_numpy(float), y


def model_grid():
    models = {}
    for C in [0.01, 0.03, 0.07, 0.1, 0.2, 0.3, 0.5, 1, 2, 3, 5, 8, 12]:
        models[f"logit_bal_C{C}"] = LogisticRegression(C=C, class_weight="balanced", max_iter=5000, solver="lbfgs")
        models[f"logit_C{C}"] = LogisticRegression(C=C, max_iter=5000, solver="lbfgs")
        models[f"ridge_bal_alpha{1/C:.3g}"] = RidgeClassifier(alpha=1/C, class_weight="balanced")
        models[f"linsvc_bal_C{C}"] = LinearSVC(C=C, class_weight="balanced", max_iter=20000, random_state=RANDOM_STATE)
    for C in [0.1, 0.3, 0.7, 1, 2, 3, 5, 8]:
        for gamma in ["scale", 0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.12]:
            models[f"rbf_C{C}_g{gamma}"] = SVC(C=C, gamma=gamma, kernel="rbf", class_weight="balanced", random_state=RANDOM_STATE)
    for C in [0.03, 0.1, 0.3, 1, 3]:
        base = LogisticRegression(C=C, class_weight="balanced", max_iter=5000, solver="lbfgs")
        models[f"logit_threshold_C{C}"] = ProbabilityThresholdClassifier(base, grid_size=31)
    models["lda"] = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    for reg in [0, 0.1, 0.2, 0.35, 0.5, 0.7]:
        models[f"qda_reg{reg}"] = QuadraticDiscriminantAnalysis(reg_param=reg)
    models["gnb"] = GaussianNB()
    for k in [3, 5, 7, 9, 11, 15, 21, 31]:
        models[f"knn{k}"] = KNeighborsClassifier(n_neighbors=k, weights="distance")
    for alpha in [1e-5, 3e-5, 1e-4, 3e-4, 1e-3]:
        models[f"sgd_log_alpha{alpha}"] = SGDClassifier(loss="log_loss", alpha=alpha, class_weight="balanced", max_iter=4000, random_state=RANDOM_STATE)
    return models


def eval_oof(X, y, est):
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    pred = np.zeros(len(y), dtype=int)
    for tr, te in cv.split(X, y):
        m = clone(est)
        m.fit(X.iloc[tr], y[tr])
        pred[te] = m.predict(X.iloc[te])
    return pred


def main():
    datasets, y_score, y = build_datasets()
    models = model_grid()
    rows = []
    best = -1
    best_pred = None
    best_name = None
    checked = 0
    for dname, X in datasets.items():
        selectors = ["none"]
        if X.shape[1] >= 15:
            selectors += [f"mi{k}" for k in [8, 12, 16, 20, 25, 30, 35, 40, 50, 60, 80] if k < X.shape[1]]
            selectors += [f"f{k}" for k in [8, 12, 16, 20, 25, 30, 35, 40, 50, 60, 80] if k < X.shape[1]]
        for sel in selectors:
            for mname, model in models.items():
                poly = False
                # Polynomial interactions only after strong feature filtering.
                if sel in {"mi8", "mi12", "f8", "f12"} and (mname.startswith("logit") or mname.startswith("ridge")):
                    poly_options = [False, True]
                else:
                    poly_options = [False]
                for poly in poly_options:
                    est = make_pipeline(model, selector=sel, poly=poly)
                    try:
                        pred = eval_oof(X, y, est)
                    except Exception as e:
                        continue
                    row = {
                        "dataset": dname,
                        "n_features": X.shape[1],
                        "selector": sel,
                        "poly_interactions": poly,
                        "model": mname,
                        "accuracy_3": accuracy_score(y, pred),
                        "balanced_accuracy_3": balanced_accuracy_score(y, pred),
                        "macro_f1_3": f1_score(y, pred, average="macro"),
                    }
                    rows.append(row)
                    checked += 1
                    if row["macro_f1_3"] > best:
                        best = row["macro_f1_3"]
                        best_pred = pred.copy()
                        best_name = row.copy()
                        print("NEW_BEST", best, best_name, flush=True)
                    if checked % 100 == 0:
                        print("checked", checked, "best", best, flush=True)
                    if best >= 0.55:
                        print("Reached target 0.55; stopping early.", flush=True)
                        break
                if best >= 0.55:
                    break
            if best >= 0.55:
                break
        if best >= 0.55:
            break
    out = pd.DataFrame(rows).sort_values(["macro_f1_3", "balanced_accuracy_3"], ascending=False)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUT_DIR / "teacher_3class_fast_small_sample_results.csv"
    pred_path = OUT_DIR / "teacher_3class_fast_small_sample_best_predictions.csv"
    out.to_csv(out_path, index=False)
    pd.DataFrame({"Empathy_Score": y_score, "true_3class": y+1, "pred_3class": best_pred+1}).to_csv(pred_path, index=False)
    print("Top candidates:")
    print(out.head(30).to_string(index=False))
    print(f"Saved: {out_path}")
    print(f"Saved: {pred_path}")

if __name__ == "__main__":
    main()

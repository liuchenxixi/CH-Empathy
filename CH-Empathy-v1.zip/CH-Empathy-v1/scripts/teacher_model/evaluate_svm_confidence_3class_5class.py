
from __future__ import annotations

import warnings
import numpy as np
import pandas as pd
from scipy.stats import entropy as scipy_entropy
from sklearn.base import clone
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, confusion_matrix
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from compare_reduced_feature_teachers import load_seed_semantic, semantic_numeric
from shared import OUT_DIR, apply_bins, load_seed_onehot, load_seed_scores, quantile_bins

warnings.filterwarnings("ignore")
RANDOM_STATE = 42


def build_data():
    _, y_level_5, y_score, _ = load_seed_onehot()
    seed_sem = load_seed_semantic(load_seed_scores())
    X = semantic_numeric(seed_sem)
    y_3 = np.asarray(apply_bins(y_score, quantile_bins(y_score, 3)), dtype=int)
    y_5 = y_level_5.to_numpy(dtype=int)
    return X, y_score.to_numpy(float), y_3, y_5


def svm_pipeline(C=1.0, gamma=0.01):
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("model", SVC(
            C=C,
            gamma=gamma,
            kernel="rbf",
            class_weight="balanced",
            probability=True,
            random_state=RANDOM_STATE,
        )),
    ])


def oof_predict_proba(X, y, C=1.0, gamma=0.01):
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    classes = np.sort(np.unique(y))
    proba = np.zeros((len(y), len(classes)), dtype=float)
    pred = np.zeros(len(y), dtype=int)
    fold_id = np.zeros(len(y), dtype=int)
    for fold, (train_idx, test_idx) in enumerate(cv.split(X, y), start=1):
        model = svm_pipeline(C=C, gamma=gamma)
        model.fit(X.iloc[train_idx], y[train_idx])
        fold_proba = model.predict_proba(X.iloc[test_idx])
        fold_classes = model.named_steps["model"].classes_
        aligned = np.zeros((len(test_idx), len(classes)), dtype=float)
        for j, cls in enumerate(fold_classes):
            aligned[:, np.where(classes == cls)[0][0]] = fold_proba[:, j]
        proba[test_idx] = aligned
        pred[test_idx] = classes[np.argmax(aligned, axis=1)]
        fold_id[test_idx] = fold
    return pred, proba, fold_id, classes


def metrics(y, pred):
    return {
        "accuracy": accuracy_score(y, pred),
        "balanced_accuracy": balanced_accuracy_score(y, pred),
        "macro_f1": f1_score(y, pred, average="macro"),
        "weighted_f1": f1_score(y, pred, average="weighted"),
    }


def confidence_scores(proba):
    sorted_proba = np.sort(proba, axis=1)
    confidence = sorted_proba[:, -1]
    margin = sorted_proba[:, -1] - sorted_proba[:, -2]
    ent = scipy_entropy(np.clip(proba, 1e-12, 1.0), axis=1)
    normalized_entropy = ent / np.log(proba.shape[1])
    return confidence, margin, normalized_entropy


def group_quality(y, pred, confidence, margin, normalized_entropy, task_name):
    rows = []
    specs = [
        ("confidence", confidence, False),
        ("margin", margin, False),
        ("entropy", normalized_entropy, True),
    ]
    for score_name, values, lower_is_better in specs:
        if lower_is_better:
            high_mask = values <= np.quantile(values, 0.30)
            low_mask = values >= np.quantile(values, 0.70)
        else:
            high_mask = values >= np.quantile(values, 0.70)
            low_mask = values <= np.quantile(values, 0.30)
        middle_mask = ~(high_mask | low_mask)
        for group, mask in [
            ("high_confidence_30pct", high_mask),
            ("middle_40pct", middle_mask),
            ("low_confidence_30pct", low_mask),
            ("all", np.ones(len(y), dtype=bool)),
        ]:
            m = metrics(y[mask], pred[mask])
            rows.append({
                "task": task_name,
                "score": score_name,
                "group": group,
                "n": int(mask.sum()),
                "mean_score": float(np.mean(values[mask])),
                **m,
            })
    return rows


def per_class_report(y, pred, task_name):
    labels = np.sort(np.unique(y))
    cm = confusion_matrix(y, pred, labels=labels)
    return pd.DataFrame(cm, index=[f"true_{x}" for x in labels], columns=[f"pred_{x}" for x in labels]).assign(task=task_name)


def main():
    X, y_score, y3, y5 = build_data()
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # Best strict OOF setting found so far for three-level labels.
    pred3, proba3, fold3, classes3 = oof_predict_proba(X, y3, C=1.0, gamma=0.01)
    conf3, margin3, ent3 = confidence_scores(proba3)

    # Five-level labels are evaluated only as an auxiliary field.
    pred5, proba5, fold5, classes5 = oof_predict_proba(X, y5, C=1.0, gamma=0.01)
    conf5, margin5, ent5 = confidence_scores(proba5)

    summary_rows = []
    summary_rows.append({"task": "3class", "score": "all", "group": "all", "n": len(y3), "mean_score": np.nan, **metrics(y3, pred3)})
    summary_rows.append({"task": "5class", "score": "all", "group": "all", "n": len(y5), "mean_score": np.nan, **metrics(y5, pred5)})
    summary_rows.extend(group_quality(y3, pred3, conf3, margin3, ent3, "3class"))
    summary_rows.extend(group_quality(y5, pred5, conf5, margin5, ent5, "5class"))
    summary = pd.DataFrame(summary_rows)

    pred_df = pd.DataFrame({
        "Empathy_Score": y_score,
        "fold_3class": fold3,
        "true_3class": y3,
        "pred_3class": pred3,
        "confidence_3class": conf3,
        "margin_3class": margin3,
        "entropy_3class": ent3,
        "fold_5class": fold5,
        "true_5class": y5,
        "pred_5class": pred5,
        "confidence_5class": conf5,
        "margin_5class": margin5,
        "entropy_5class": ent5,
    })
    for i, cls in enumerate(classes3):
        pred_df[f"proba_3class_{cls}"] = proba3[:, i]
    for i, cls in enumerate(classes5):
        pred_df[f"proba_5class_{cls}"] = proba5[:, i]

    summary_path = OUT_DIR / "svm_confidence_3class_5class_summary.csv"
    pred_path = OUT_DIR / "svm_confidence_3class_5class_oof_predictions.csv"
    cm3_path = OUT_DIR / "svm_confidence_3class_confusion_matrix.csv"
    cm5_path = OUT_DIR / "svm_confidence_5class_confusion_matrix.csv"
    summary.to_csv(summary_path, index=False)
    pred_df.to_csv(pred_path, index=False)
    per_class_report(y3, pred3, "3class").to_csv(cm3_path)
    per_class_report(y5, pred5, "5class").to_csv(cm5_path)

    print("Overall metrics:")
    print(summary[summary["score"].eq("all")][["task", "n", "accuracy", "balanced_accuracy", "macro_f1", "weighted_f1"]].to_string(index=False))
    print("\nConfidence-group metrics:")
    keep = summary[(summary["score"].isin(["confidence", "margin", "entropy"])) & (summary["group"].isin(["high_confidence_30pct", "low_confidence_30pct", "all"]))]
    print(keep[["task", "score", "group", "n", "mean_score", "accuracy", "balanced_accuracy", "macro_f1", "weighted_f1"]].to_string(index=False))
    print(f"\nSaved: {summary_path}")
    print(f"Saved: {pred_path}")


if __name__ == "__main__":
    main()

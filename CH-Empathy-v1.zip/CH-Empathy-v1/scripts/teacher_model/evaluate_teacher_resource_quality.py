from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import mutual_info_regression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold

from shared import apply_bins, ensure_out_dir, load_seed_onehot, quantile_bins


SUMMARY_PATH = ensure_out_dir() / "teacher_mi_regression_cv_summary.csv"


def make_model() -> RandomForestRegressor:
    return RandomForestRegressor(
        n_estimators=500,
        max_depth=12,
        min_samples_leaf=3,
        random_state=42,
        n_jobs=-1,
    )


def selected_budget(default: int | str = 80) -> int | str:
    if not SUMMARY_PATH.exists():
        return default
    summary = pd.read_csv(SUMMARY_PATH)
    best = summary.sort_values(
        by=["macro_f1_3", "Spearman", "RMSE"],
        ascending=[False, False, True],
        kind="mergesort",
    ).iloc[0]["budget"]
    if str(best).lower() == "all":
        return "all"
    return int(best)


def select_mi_features(X_train: pd.DataFrame, y_train: pd.Series, budget: int | str) -> list[str]:
    if budget == "all" or int(budget) >= X_train.shape[1]:
        return list(X_train.columns)
    discrete = np.array([pd.Series(X_train[col]).dropna().nunique() <= 20 for col in X_train.columns])
    scores = mutual_info_regression(X_train, y_train, discrete_features=discrete, random_state=42)
    return list(pd.Series(scores, index=X_train.columns).sort_values(ascending=False, kind="mergesort").head(int(budget)).index)


def metric_row(name: str, y_true, y_pred, bins_3, bins_5) -> dict:
    truth = pd.Series(np.asarray(y_true, dtype=float)).reset_index(drop=True)
    pred = pd.Series(np.asarray(y_pred, dtype=float)).reset_index(drop=True)
    true_3, pred_3 = apply_bins(truth, bins_3), apply_bins(pred, bins_3)
    true_5, pred_5 = apply_bins(truth, bins_5), apply_bins(pred, bins_5)
    return {
        "setting": name,
        "n": int(len(truth)),
        "MAE": float(mean_absolute_error(truth, pred)),
        "RMSE": float(np.sqrt(mean_squared_error(truth, pred))),
        "R2": float(r2_score(truth, pred)) if len(truth) > 1 else np.nan,
        "Pearson": float(truth.corr(pred, method="pearson")) if len(truth) > 1 else np.nan,
        "Spearman": float(truth.corr(pred, method="spearman")) if len(truth) > 1 else np.nan,
        "acc_3": float(accuracy_score(true_3, pred_3)),
        "bal_acc_3": float(balanced_accuracy_score(true_3, pred_3)),
        "macro_f1_3": float(f1_score(true_3, pred_3, average="macro")),
        "acc_5": float(accuracy_score(true_5, pred_5)),
        "bal_acc_5": float(balanced_accuracy_score(true_5, pred_5)),
        "macro_f1_5": float(f1_score(true_5, pred_5, average="macro")),
    }


def classification_baseline_row(name: str, y_true_3, y_pred_3) -> dict:
    return {
        "setting": name,
        "n": int(len(y_true_3)),
        "acc_3": float(accuracy_score(y_true_3, y_pred_3)),
        "bal_acc_3": float(balanced_accuracy_score(y_true_3, y_pred_3)),
        "macro_f1_3": float(f1_score(y_true_3, y_pred_3, average="macro")),
    }


def main() -> None:
    out_dir = ensure_out_dir()
    X_seed, _y_level_5, y_score, _feature_cols = load_seed_onehot()
    bins_3 = quantile_bins(y_score, q=3)
    bins_5 = quantile_bins(y_score, q=5)
    budget = selected_budget()

    rows = []
    oof_parts = []
    baseline_score_parts = []
    majority_parts = []
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    for fold, (train_idx, valid_idx) in enumerate(kf.split(X_seed), start=1):
        X_train, y_train = X_seed.iloc[train_idx], y_score.iloc[train_idx]
        X_valid, y_valid = X_seed.iloc[valid_idx], y_score.iloc[valid_idx]
        selected = select_mi_features(X_train, y_train, budget)
        model = make_model()
        model.fit(X_train[selected], y_train)
        pred = model.predict(X_valid[selected])
        tree_preds = np.vstack([tree.predict(X_valid[selected].to_numpy()) for tree in model.estimators_])
        uncertainty = tree_preds.std(axis=0)

        mean_pred = np.full(len(valid_idx), float(y_train.mean()))
        train_level_3 = apply_bins(y_train, bins_3)
        majority_level = int(train_level_3.value_counts().idxmax())
        majority_pred_3 = np.full(len(valid_idx), majority_level)

        truth_3 = apply_bins(y_valid, bins_3)
        pred_3 = apply_bins(pred, bins_3)
        oof_parts.append(
            pd.DataFrame(
                {
                    "fold": fold,
                    "seed_index": valid_idx,
                    "y_true": y_valid.to_numpy(dtype=float),
                    "y_pred": pred,
                    "uncertainty": uncertainty,
                    "true_level_3": np.asarray(truth_3, dtype=int),
                    "pred_level_3": np.asarray(pred_3, dtype=int),
                }
            )
        )
        baseline_score_parts.append(pd.DataFrame({"y_true": y_valid.to_numpy(dtype=float), "y_pred": mean_pred}))
        majority_parts.append(pd.DataFrame({"true_level_3": np.asarray(truth_3, dtype=int), "pred_level_3": majority_pred_3}))
        rows.append(metric_row(f"teacher_fold_{fold}", y_valid, pred, bins_3, bins_5))

    oof = pd.concat(oof_parts, ignore_index=True).sort_values("seed_index", kind="mergesort")
    mean_baseline = pd.concat(baseline_score_parts, ignore_index=True)
    majority_baseline = pd.concat(majority_parts, ignore_index=True)

    oof.to_csv(out_dir / "teacher_mi_regression_oof_predictions.csv", index=False, encoding="utf-8-sig")

    baseline_rows = [
        metric_row("teacher_oof", oof["y_true"], oof["y_pred"], bins_3, bins_5),
        metric_row("mean_score_baseline", mean_baseline["y_true"], mean_baseline["y_pred"], bins_3, bins_5),
        classification_baseline_row(
            "majority_label_baseline",
            majority_baseline["true_level_3"],
            majority_baseline["pred_level_3"],
        ),
    ]
    baseline = pd.DataFrame(baseline_rows)
    teacher = baseline.loc[baseline["setting"] == "teacher_oof"].iloc[0]
    mean_base = baseline.loc[baseline["setting"] == "mean_score_baseline"].iloc[0]
    maj_base = baseline.loc[baseline["setting"] == "majority_label_baseline"].iloc[0]
    baseline.loc[baseline["setting"] == "teacher_oof", "MAE_improvement_vs_mean_pct"] = (
        (mean_base["MAE"] - teacher["MAE"]) / mean_base["MAE"] * 100.0
    )
    baseline.loc[baseline["setting"] == "teacher_oof", "RMSE_improvement_vs_mean_pct"] = (
        (mean_base["RMSE"] - teacher["RMSE"]) / mean_base["RMSE"] * 100.0
    )
    baseline.loc[baseline["setting"] == "teacher_oof", "macro_f1_3_gain_vs_majority"] = teacher["macro_f1_3"] - maj_base["macro_f1_3"]
    baseline.to_csv(out_dir / "teacher_mi_regression_baseline_comparison.csv", index=False, encoding="utf-8-sig")

    q30 = float(oof["uncertainty"].quantile(0.30))
    q70 = float(oof["uncertainty"].quantile(0.70))
    groups = [
        ("low_uncertainty_30pct", oof[oof["uncertainty"] <= q30]),
        ("all_oof", oof),
        ("high_uncertainty_30pct", oof[oof["uncertainty"] >= q70]),
    ]
    uncertainty_rows = []
    for name, part in groups:
        row = metric_row(name, part["y_true"], part["y_pred"], bins_3, bins_5)
        row["uncertainty_mean"] = float(part["uncertainty"].mean())
        row["uncertainty_median"] = float(part["uncertainty"].median())
        uncertainty_rows.append(row)
    uncertainty_summary = pd.DataFrame(uncertainty_rows)
    uncertainty_summary.to_csv(out_dir / "teacher_mi_regression_uncertainty_groups.csv", index=False, encoding="utf-8-sig")

    print(f"best budget: {budget}")
    print("\nBaseline comparison:")
    print(baseline.to_string(index=False))
    print("\nUncertainty groups:")
    print(uncertainty_summary.to_string(index=False))
    print(f"\noutputs saved in: {out_dir}")


if __name__ == "__main__":
    main()

from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold

from shared import apply_bins, ensure_out_dir, load_cgss2023_onehot, load_seed_onehot, quantile_bins


def regression_report(y_true: pd.Series, y_pred: np.ndarray) -> dict[str, float]:
    truth = pd.Series(np.asarray(y_true, dtype=float)).reset_index(drop=True)
    pred = pd.Series(np.asarray(y_pred, dtype=float)).reset_index(drop=True)
    return {
        "MAE": float(mean_absolute_error(truth, pred)),
        "RMSE": float(np.sqrt(mean_squared_error(truth, pred))),
        "R2": float(r2_score(truth, pred)),
        "Spearman": float(truth.corr(pred, method="spearman")),
    }


def cls_report(y_true_score: pd.Series, y_pred_score: np.ndarray, bins: np.ndarray) -> dict[str, float]:
    truth = apply_bins(y_true_score, bins)
    pred = apply_bins(y_pred_score, bins)
    return {
        "accuracy": float(accuracy_score(truth, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(truth, pred)),
        "macro_F1": float(f1_score(truth, pred, average="macro")),
        "weighted_F1": float(f1_score(truth, pred, average="weighted")),
    }


def main() -> None:
    out_dir = ensure_out_dir()
    X_seed, _y_level_5, y_score, _features = load_seed_onehot()
    row_ids, X_cgss2023, _features = load_cgss2023_onehot()

    bins_3 = quantile_bins(y_score, q=3)
    bins_5 = quantile_bins(y_score, q=5)
    model = RandomForestRegressor(
        n_estimators=500,
        max_depth=12,
        min_samples_leaf=3,
        random_state=42,
        n_jobs=-1,
    )

    rows = []
    kf = KFold(n_splits=min(5, len(X_seed)), shuffle=True, random_state=42)
    for fold, (train_idx, valid_idx) in enumerate(kf.split(X_seed), start=1):
        model.fit(X_seed.iloc[train_idx], y_score.iloc[train_idx])
        pred = model.predict(X_seed.iloc[valid_idx])
        truth = y_score.iloc[valid_idx]
        row = {"fold": fold}
        row.update({f"reg_{k}": v for k, v in regression_report(truth, pred).items()})
        row.update({f"cls3_{k}": v for k, v in cls_report(truth, pred, bins_3).items()})
        row.update({f"cls5_{k}": v for k, v in cls_report(truth, pred, bins_5).items()})
        rows.append(row)
        print(
            f"fold {fold}: RMSE={row['reg_RMSE']:.4f}, R2={row['reg_R2']:.4f}, "
            f"Spearman={row['reg_Spearman']:.4f}, macro_F1_3={row['cls3_macro_F1']:.4f}, "
            f"macro_F1_5={row['cls5_macro_F1']:.4f}"
        )

    cv = pd.DataFrame(rows)
    cv.to_csv(out_dir / "teacher_score_regression_cv_results.csv", index=False, encoding="utf-8-sig")

    model.fit(X_seed, y_score)
    preds = model.predict(X_cgss2023)
    tree_preds = np.vstack([tree.predict(X_cgss2023.to_numpy()) for tree in model.estimators_])
    uncertainty = tree_preds.std(axis=0)
    joblib.dump({"model": model, "bins_3": bins_3, "bins_5": bins_5, "target": "IRI_total_score"}, out_dir / "teacher_random_forest_score_regressor.joblib")

    pseudo = pd.DataFrame(
        {
            "cgss2023_row_id": row_ids,
            "Empathy_Score_Pred": preds,
            "Empathy_Score_Uncertainty": uncertainty,
            "Empathy_Level_3": apply_bins(preds, bins_3),
            "Empathy_Level_5": apply_bins(preds, bins_5),
        }
    )
    pseudo.to_csv(out_dir / "CGSS2023_Pseudo_Labeled_score_regression.csv", index=False, encoding="utf-8-sig")

    print("\ncv mean:")
    print(cv.drop(columns=["fold"]).mean().to_string())
    print("\nCGSS2023 derived 3-class distribution:")
    print(pseudo["Empathy_Level_3"].value_counts().sort_index())
    print("\nCGSS2023 derived 5-class distribution:")
    print(pseudo["Empathy_Level_5"].value_counts().sort_index())
    print(f"\noutputs saved in: {out_dir}")


if __name__ == "__main__":
    main()

from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import entropy as scipy_entropy
from sklearn.metrics import accuracy_score, adjusted_rand_score, f1_score

from compare_reduced_feature_teachers import load_seed_semantic, semantic_numeric
from evaluate_svm_confidence_3class_5class import (
    confidence_scores,
    metrics,
    oof_predict_proba,
    svm_pipeline,
)
from shared import apply_bins, load_seed_onehot, load_seed_scores, quantile_bins

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[2]
THIS_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "2023" / "data"
OUT_DIR = THIS_DIR / "results"
PROCESS_SCHEMA_DIR = PROJECT_ROOT / "process" / "new_schema"
sys.path.append(str(PROCESS_SCHEMA_DIR))

from feature_schema import SEMANTIC_FEATURES  # noqa: E402


def load_seed_training_data() -> tuple[pd.DataFrame, np.ndarray]:
    _, _, y_score, _ = load_seed_onehot()
    seed_semantic = load_seed_semantic(load_seed_scores())
    x_seed = semantic_numeric(seed_semantic)
    y_3 = np.asarray(apply_bins(y_score, quantile_bins(y_score, 3)), dtype=int)
    return x_seed, y_3


def load_cgss_features() -> tuple[pd.Series, pd.DataFrame]:
    cgss_path = DATA_DIR / "cgss2023_semantic.csv"
    if not cgss_path.exists():
        raise FileNotFoundError(f"Missing CGSS semantic features: {cgss_path}")
    cgss = pd.read_csv(cgss_path)
    missing = [col for col in SEMANTIC_FEATURES if col not in cgss.columns]
    if missing:
        raise ValueError(f"cgss2023_semantic.csv is missing columns: {missing[:10]}")
    x_cgss = semantic_numeric(cgss[SEMANTIC_FEATURES])
    return cgss["cgss2023_row_id"], x_cgss


def aligned_predict_proba(model, x: pd.DataFrame, classes: np.ndarray) -> np.ndarray:
    proba = model.predict_proba(x)
    model_classes = model.named_steps["model"].classes_
    aligned = np.zeros((len(x), len(classes)), dtype=float)
    for j, cls in enumerate(model_classes):
        aligned[:, np.where(classes == cls)[0][0]] = proba[:, j]
    return aligned


def summarize_distribution(name: str, labels: pd.Series) -> pd.DataFrame:
    counts = labels.value_counts().sort_index()
    return pd.DataFrame(
        {
            "label_source": name,
            "label": counts.index.astype(int),
            "n": counts.values.astype(int),
            "proportion": counts.values / counts.values.sum(),
        }
    )


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    x_seed, y_seed_3 = load_seed_training_data()
    x_cgss_id, x_cgss = load_cgss_features()
    classes = np.array([1, 2, 3])

    # Strict seed-level validation: every seed prediction is out-of-fold.
    seed_pred, seed_proba, _, _ = oof_predict_proba(x_seed, y_seed_3, C=1.0, gamma=0.01)
    seed_conf, seed_margin, seed_entropy = confidence_scores(seed_proba)
    seed_quality = {
        "seed_oof_accuracy": accuracy_score(y_seed_3, seed_pred),
        "seed_oof_macro_f1": f1_score(y_seed_3, seed_pred, average="macro"),
        "seed_oof_weighted_f1": f1_score(y_seed_3, seed_pred, average="weighted"),
        "seed_high_margin_30pct_macro_f1": f1_score(
            y_seed_3[seed_margin >= np.quantile(seed_margin, 0.70)],
            seed_pred[seed_margin >= np.quantile(seed_margin, 0.70)],
            average="macro",
        ),
        "seed_low_margin_30pct_macro_f1": f1_score(
            y_seed_3[seed_margin <= np.quantile(seed_margin, 0.30)],
            seed_pred[seed_margin <= np.quantile(seed_margin, 0.30)],
            average="macro",
        ),
    }

    # Final teacher for release: train on all seed samples, then assign CGSS weak labels.
    final_model = svm_pipeline(C=1.0, gamma=0.01)
    final_model.fit(x_seed, y_seed_3)
    cgss_proba = aligned_predict_proba(final_model, x_cgss, classes)
    cgss_pred = classes[np.argmax(cgss_proba, axis=1)]
    cgss_conf, cgss_margin, cgss_entropy = confidence_scores(cgss_proba)

    svm_df = pd.DataFrame(
        {
            "cgss2023_row_id": x_cgss_id,
            "Empathy_Level_3_SVM": cgss_pred,
            "SVM_Prob_Level_1": cgss_proba[:, 0],
            "SVM_Prob_Level_2": cgss_proba[:, 1],
            "SVM_Prob_Level_3": cgss_proba[:, 2],
            "SVM_Confidence": cgss_conf,
            "SVM_Margin": cgss_margin,
            "SVM_Entropy": cgss_entropy,
        }
    )
    svm_path = DATA_DIR / "CGSS2023_SVM_Auxiliary_3class.csv"
    svm_df.to_csv(svm_path, index=False)

    base_path = DATA_DIR / "CGSS2023_Pseudo_Labeled_mi_internal_3class.csv"
    merged_path = DATA_DIR / "CGSS2023_Pseudo_Labeled_mi_internal_3class_with_svm_aux.csv"
    report_rows = []
    dist_tables = [summarize_distribution("svm_auxiliary", svm_df["Empathy_Level_3_SVM"])]

    if base_path.exists():
        base = pd.read_csv(base_path)
        merged = base.merge(svm_df, on="cgss2023_row_id", how="left")
        merged.to_csv(merged_path, index=False)
        if "Empathy_Level_3" in merged.columns:
            y_score_tertile = merged["Empathy_Level_3"].astype(int)
            y_svm = merged["Empathy_Level_3_SVM"].astype(int)
            agreement = y_score_tertile.eq(y_svm)
            high_margin = merged["SVM_Margin"] >= merged["SVM_Margin"].quantile(0.70)
            low_margin = merged["SVM_Margin"] <= merged["SVM_Margin"].quantile(0.30)
            report_rows.extend(
                [
                    ("cgss_svm_vs_score_tertile_agreement", float(agreement.mean())),
                    (
                        "cgss_svm_vs_score_tertile_macro_f1_reference_only",
                        float(f1_score(y_score_tertile, y_svm, average="macro")),
                    ),
                    (
                        "cgss_svm_vs_score_tertile_adjusted_rand_reference_only",
                        float(adjusted_rand_score(y_score_tertile, y_svm)),
                    ),
                    ("cgss_high_margin_30pct_agreement", float(agreement[high_margin].mean())),
                    ("cgss_low_margin_30pct_agreement", float(agreement[low_margin].mean())),
                    ("cgss_high_margin_30pct_n", int(high_margin.sum())),
                    ("cgss_low_margin_30pct_n", int(low_margin.sum())),
                ]
            )
            dist_tables.append(summarize_distribution("score_internal_tertile", y_score_tertile))
    else:
        merged_path = None

    for key, value in seed_quality.items():
        report_rows.insert(0, (key, value))
    report_rows.extend(
        [
            ("cgss_n", int(len(svm_df))),
            ("cgss_svm_margin_mean", float(np.mean(cgss_margin))),
            ("cgss_svm_margin_p30", float(np.quantile(cgss_margin, 0.30))),
            ("cgss_svm_margin_p70", float(np.quantile(cgss_margin, 0.70))),
            ("cgss_svm_entropy_mean", float(np.mean(cgss_entropy))),
        ]
    )

    report = pd.DataFrame(report_rows, columns=["metric", "value"])
    report_path = OUT_DIR / "svm_auxiliary_cgss_quality_report.csv"
    dist_path = OUT_DIR / "svm_auxiliary_cgss_label_distribution.csv"
    report.to_csv(report_path, index=False)
    pd.concat(dist_tables, ignore_index=True).to_csv(dist_path, index=False)

    print("Saved:", svm_path)
    if merged_path is not None:
        print("Saved:", merged_path)
    print("Saved:", report_path)
    print("Saved:", dist_path)
    print()
    print(report.to_string(index=False))
    print()
    print(pd.concat(dist_tables, ignore_index=True).to_string(index=False))


if __name__ == "__main__":
    main()

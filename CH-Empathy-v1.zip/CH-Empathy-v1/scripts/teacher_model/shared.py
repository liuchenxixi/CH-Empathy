from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROCESS_SCHEMA_DIR = PROJECT_ROOT / "process" / "new_schema"
PROCESS_DATA_DIR = PROJECT_ROOT / "process" / "data"
CGSS2023_DIR = PROJECT_ROOT / "2023"
CGSS2023_DATA_DIR = CGSS2023_DIR / "data"
OUT_DIR = Path(__file__).resolve().parent / "results"

sys.path.append(str(PROCESS_SCHEMA_DIR))

from build_seed_features import compute_iri_total_score  # noqa: E402
from feature_schema import load_feature_columns  # noqa: E402


SEED_FILES = [
    (PROCESS_DATA_DIR / "417.xlsx", "417.xlsx"),
    (PROCESS_DATA_DIR / "new126.xlsx", "new126.xlsx"),
]


def ensure_out_dir() -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUT_DIR


def feature_columns() -> list[str]:
    return load_feature_columns(PROCESS_DATA_DIR / "new_schema" / "onehot_feature_columns.json")


def load_seed_onehot() -> tuple[pd.DataFrame, pd.Series, pd.Series, list[str]]:
    seed_path = PROCESS_DATA_DIR / "new_schema" / "seed_onehot.csv"
    if not seed_path.exists():
        raise FileNotFoundError(f"Missing seed onehot file: {seed_path}")
    features = feature_columns()
    seed = pd.read_csv(seed_path)
    y_level_5 = pd.to_numeric(seed["Empathy_Level"], errors="coerce")
    y_score = load_seed_scores()
    valid = y_level_5.notna() & y_score.notna()
    return (
        seed.loc[valid, features].reset_index(drop=True),
        y_level_5.loc[valid].astype(int).reset_index(drop=True),
        y_score.loc[valid].reset_index(drop=True),
        features,
    )


def load_seed_scores() -> pd.Series:
    pieces = []
    for path, source_name in SEED_FILES:
        if not path.exists():
            raise FileNotFoundError(f"Missing seed survey file: {path}")
        df = pd.read_excel(path)
        pieces.append(
            pd.DataFrame(
                {
                    "source_file": source_name,
                    "Empathy_Score": compute_iri_total_score(df).reset_index(drop=True),
                }
            )
        )
    return pd.concat(pieces, ignore_index=True)["Empathy_Score"]


def load_cgss2023_onehot() -> tuple[pd.Series, pd.DataFrame, list[str]]:
    cgss_path = CGSS2023_DATA_DIR / "cgss2023_onehot.csv"
    if not cgss_path.exists():
        raise FileNotFoundError(f"Missing CGSS2023 onehot file: {cgss_path}. Run ../build_cgss2023_features.py first.")
    features = feature_columns()
    cgss = pd.read_csv(cgss_path)
    missing = [col for col in features if col not in cgss.columns]
    if missing:
        raise ValueError(f"CGSS2023 onehot is not aligned; missing columns: {missing[:10]}")
    row_ids = cgss["cgss2023_row_id"] if "cgss2023_row_id" in cgss.columns else pd.Series(np.arange(len(cgss)))
    return row_ids, cgss[features], features


def quantile_bins(scores: pd.Series, q: int) -> np.ndarray:
    _codes, bins = pd.qcut(scores, q=q, labels=False, retbins=True, duplicates="drop")
    bins = np.asarray(bins, dtype=float)
    bins[0] = -np.inf
    bins[-1] = np.inf
    return bins


def apply_bins(values, bins: np.ndarray) -> pd.Series:
    labels = list(range(1, len(bins)))
    return pd.cut(values, bins=bins, labels=labels, include_lowest=True).astype(int)


def write_json(data, path: Path) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

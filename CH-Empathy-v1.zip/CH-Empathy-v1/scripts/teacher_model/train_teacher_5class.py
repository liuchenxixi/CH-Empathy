from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import StratifiedKFold

from shared import ensure_out_dir, load_cgss2023_onehot, load_seed_onehot


def main() -> None:
    out_dir = ensure_out_dir()
    X_seed, y_seed, _y_score, _features = load_seed_onehot()
    row_ids, X_cgss2023, _features = load_cgss2023_onehot()

    model = RandomForestClassifier(
        n_estimators=500,
        max_depth=12,
        min_samples_leaf=3,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )

    labels = sorted(y_seed.unique())
    n_splits = min(5, int(y_seed.value_counts().min()))
    rows = []
    total_cm = np.zeros((len(labels), len(labels)), dtype=int)
    if n_splits >= 2:
        kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
        for fold, (train_idx, valid_idx) in enumerate(kf.split(X_seed, y_seed), start=1):
            model.fit(X_seed.iloc[train_idx], y_seed.iloc[train_idx])
            pred = model.predict(X_seed.iloc[valid_idx])
            truth = y_seed.iloc[valid_idx]
            row = {
                "fold": fold,
                "accuracy": float(accuracy_score(truth, pred)),
                "balanced_accuracy": float(balanced_accuracy_score(truth, pred)),
                "macro_F1": float(f1_score(truth, pred, average="macro")),
                "weighted_F1": float(f1_score(truth, pred, average="weighted")),
            }
            rows.append(row)
            total_cm += confusion_matrix(truth, pred, labels=labels)
            print(
                f"fold {fold}: accuracy={row['accuracy']:.4f}, "
                f"balanced_accuracy={row['balanced_accuracy']:.4f}, "
                f"macro_F1={row['macro_F1']:.4f}, weighted_F1={row['weighted_F1']:.4f}"
            )

    cv = pd.DataFrame(rows)
    cv.to_csv(out_dir / "teacher_5class_cv_results.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(total_cm, index=labels, columns=labels).to_csv(out_dir / "teacher_5class_cv_confusion_matrix.csv", encoding="utf-8-sig")

    model.fit(X_seed, y_seed)
    preds = model.predict(X_cgss2023).astype(int)
    proba = model.predict_proba(X_cgss2023)
    classes = model.classes_.astype(int)
    expected = proba @ classes
    confidence = proba.max(axis=1)

    joblib.dump(model, out_dir / "teacher_random_forest_5class.joblib")

    pseudo = pd.DataFrame(
        {
            "cgss2023_row_id": row_ids,
            "Empathy_Level_Pred": preds,
            "Empathy_Level_Expected": expected,
            "Empathy_Level_Confidence": confidence,
        }
    )
    for class_label, class_proba in zip(classes, proba.T):
        pseudo[f"Empathy_Level_Prob_{class_label}"] = class_proba
    pseudo.to_csv(out_dir / "CGSS2023_Pseudo_Labeled_5class.csv", index=False, encoding="utf-8-sig")

    print("\ncv mean:")
    print(cv.drop(columns=["fold"]).mean().to_string())
    print("\nclassification report on full seed fit:")
    print(classification_report(y_seed, model.predict(X_seed), labels=classes, digits=4))
    print("\nCGSS2023 predicted class distribution:")
    print(pd.Series(preds).value_counts().sort_index())
    print(f"\noutputs saved in: {out_dir}")


if __name__ == "__main__":
    main()

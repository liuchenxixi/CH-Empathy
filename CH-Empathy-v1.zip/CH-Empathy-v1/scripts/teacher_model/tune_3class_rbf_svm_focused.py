
from __future__ import annotations

import warnings
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from compare_reduced_feature_teachers import DOMAIN_GROUPS, domain_aggregates, load_seed_semantic, semantic_numeric
from shared import OUT_DIR, apply_bins, load_seed_onehot, load_seed_scores, quantile_bins

warnings.filterwarnings("ignore")
RANDOM_STATE = 42


def build_datasets():
    _, _, y_score, _ = load_seed_onehot()
    seed_sem = load_seed_semantic(load_seed_scores())
    X_sem = semantic_numeric(seed_sem)
    X_domain = domain_aggregates(seed_sem)
    X_plus = pd.concat([X_sem, X_domain], axis=1)
    datasets = {
        "semantic_numeric": X_sem,
        "semantic_plus_domain": X_plus,
        "domain_aggregated": X_domain,
    }
    for group, cols in DOMAIN_GROUPS.items():
        drop = set(cols + [f"{c}_missing" for c in cols])
        keep = [c for c in X_sem.columns if c not in drop]
        datasets[f"semantic_no_{group}"] = X_sem[keep]
    core_groups = ["wellbeing_health", "education_work", "hukou_resource", "class_mobility", "family_marriage", "media_leisure", "belief_public"]
    core_cols = []
    for g in core_groups:
        core_cols.extend(DOMAIN_GROUPS[g])
    core_cols = [c for c in core_cols if c in X_sem.columns]
    core_cols += [f"{c}_missing" for c in core_cols if f"{c}_missing" in X_sem.columns]
    datasets["semantic_core_social"] = X_sem[core_cols]
    y = np.asarray(apply_bins(y_score, quantile_bins(y_score, 3)), dtype=int) - 1
    return datasets, y_score.to_numpy(float), y


def make_est(selector, C, gamma, kernel="rbf"):
    steps = [("imputer", SimpleImputer(strategy="median"))]
    if selector.startswith("mi"):
        steps.append(("select", SelectKBest(mutual_info_classif, k=int(selector[2:]))))
    elif selector.startswith("f"):
        steps.append(("select", SelectKBest(f_classif, k=int(selector[1:]))))
    steps.append(("scaler", StandardScaler()))
    steps.append(("model", SVC(C=C, gamma=gamma, kernel=kernel, class_weight="balanced", random_state=RANDOM_STATE)))
    return Pipeline(steps)


def eval_oof(X, y, est):
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    pred = np.zeros(len(y), dtype=int)
    for tr, te in cv.split(X, y):
        m = clone(est)
        m.fit(X.iloc[tr], y[tr])
        pred[te] = m.predict(X.iloc[te])
    return pred


def evaluate_grid(datasets, y, grid, stage_name, start_best=-1):
    rows = []
    best = start_best
    best_pred = None
    best_row = None
    checked = 0
    for dname, selectors, Cs, gammas in grid:
        X = datasets[dname]
        for selector in selectors:
            if selector != "none" and int(selector[2:]) >= X.shape[1]:
                continue
            for C in Cs:
                for gamma in gammas:
                    est = make_est(selector, C, gamma)
                    pred = eval_oof(X, y, est)
                    row = {
                        "stage": stage_name,
                        "dataset": dname,
                        "n_features": X.shape[1],
                        "selector": selector,
                        "C": C,
                        "gamma": gamma,
                        "accuracy_3": accuracy_score(y, pred),
                        "balanced_accuracy_3": balanced_accuracy_score(y, pred),
                        "macro_f1_3": f1_score(y, pred, average="macro"),
                    }
                    rows.append(row)
                    checked += 1
                    if row["macro_f1_3"] > best:
                        best = row["macro_f1_3"]
                        best_pred = pred.copy()
                        best_row = row.copy()
                        print("NEW_BEST", best, best_row, flush=True)
                    if checked % 50 == 0:
                        print(stage_name, "checked", checked, "best", best, flush=True)
                    if best >= 0.55:
                        return rows, best, best_row, best_pred
    return rows, best, best_row, best_pred


def main():
    datasets, y_score, y = build_datasets()
    selectors_coarse = ["none", "mi20", "mi30", "mi40", "mi60", "f20", "f30", "f40", "f60"]
    high_value = [
        "semantic_numeric",
        "semantic_plus_domain",
        "semantic_no_spouse",
        "semantic_no_parents",
        "semantic_no_demographic",
        "semantic_no_belief_public",
        "semantic_no_media_leisure",
        "semantic_core_social",
    ]
    Cs = [0.4, 0.7, 1.0, 1.5, 2.0, 3.0, 5.0]
    gammas = ["scale", 0.005, 0.008, 0.01, 0.015, 0.02, 0.03, 0.05]
    grid1 = [(d, selectors_coarse, Cs, gammas) for d in high_value]
    rows1, best, best_row, best_pred = evaluate_grid(datasets, y, grid1, "coarse")

    rows = rows1
    if best_row is not None and best < 0.55:
        d = best_row["dataset"]
        sel = best_row["selector"]
        C0 = float(best_row["C"])
        gamma0 = best_row["gamma"]
        if gamma0 == "scale":
            gamma_fine = ["scale", 0.003, 0.005, 0.008, 0.01, 0.012, 0.015, 0.02]
        else:
            g0 = float(gamma0)
            gamma_fine = sorted(set([max(0.001, g0 * x) for x in [0.4, 0.6, 0.8, 1, 1.25, 1.5, 2.0, 2.5]]))
        C_fine = sorted(set([max(0.05, C0 * x) for x in [0.4, 0.6, 0.8, 1, 1.25, 1.5, 2.0, 3.0]]))
        neighbor_selectors = [sel]
        for s in ["none", "mi16", "mi20", "mi25", "mi30", "mi35", "mi40", "mi50", "f16", "f20", "f25", "f30", "f35", "f40", "f50"]:
            if s not in neighbor_selectors:
                neighbor_selectors.append(s)
        grid2 = [(d, neighbor_selectors, C_fine, gamma_fine)]
        rows2, best2, best_row2, best_pred2 = evaluate_grid(datasets, y, grid2, "fine", best)
        rows.extend(rows2)
        if best_row2 is not None and best2 >= best:
            best, best_row, best_pred = best2, best_row2, best_pred2

    out = pd.DataFrame(rows).sort_values(["macro_f1_3", "balanced_accuracy_3"], ascending=False)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUT_DIR / "teacher_3class_rbf_svm_focused_results.csv"
    pred_path = OUT_DIR / "teacher_3class_rbf_svm_focused_best_predictions.csv"
    out.to_csv(out_path, index=False)
    pd.DataFrame({"Empathy_Score": y_score, "true_3class": y+1, "pred_3class": best_pred+1}).to_csv(pred_path, index=False)
    print("Top RBF SVM candidates:")
    print(out.head(30).to_string(index=False))
    print(f"Saved: {out_path}")
    print(f"Saved: {pred_path}")

if __name__ == "__main__":
    main()

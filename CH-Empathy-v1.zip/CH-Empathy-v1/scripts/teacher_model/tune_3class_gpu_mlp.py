
from __future__ import annotations

import itertools
import random
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy.stats import pearsonr, spearmanr
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from compare_reduced_feature_teachers import domain_aggregates, load_seed_semantic, semantic_numeric
from shared import OUT_DIR, apply_bins, load_seed_onehot, load_seed_scores, quantile_bins

warnings.filterwarnings("ignore")

RANDOM_STATE = 42
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


class MLP(nn.Module):
    def __init__(self, in_dim: int, hidden: tuple[int, ...], dropout: float):
        super().__init__()
        layers = []
        last = in_dim
        for h in hidden:
            layers.extend([
                nn.Linear(last, h),
                nn.BatchNorm1d(h),
                nn.ReLU(),
                nn.Dropout(dropout),
            ])
            last = h
        layers.append(nn.Linear(last, 3))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def build_features():
    _, _, y_score, _ = load_seed_onehot()
    seed_sem = load_seed_semantic(load_seed_scores())
    X_sem = semantic_numeric(seed_sem)
    X_domain = domain_aggregates(seed_sem)
    X_plus = pd.concat([X_sem, X_domain], axis=1)
    bins_3 = quantile_bins(y_score, 3)
    y_3 = np.asarray(apply_bins(y_score, bins_3), dtype=int) - 1
    return {
        "semantic_numeric": X_sem,
        "semantic_plus_domain": X_plus,
    }, y_score.to_numpy(float), y_3


def preprocess_fit_transform(X_train, y_train, X_val, X_test, selector: str):
    imp = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    Xt = imp.fit_transform(X_train)
    Xv = imp.transform(X_val)
    Xs = imp.transform(X_test)
    sel = None
    if selector != "all":
        method, k_s = selector[:2], int(selector[2:])
        k = min(k_s, Xt.shape[1])
        score_func = mutual_info_classif if method == "mi" else f_classif
        sel = SelectKBest(score_func, k=k)
        Xt = sel.fit_transform(Xt, y_train)
        Xv = sel.transform(Xv)
        Xs = sel.transform(Xs)
    Xt = scaler.fit_transform(Xt).astype("float32")
    Xv = scaler.transform(Xv).astype("float32")
    Xs = scaler.transform(Xs).astype("float32")
    return Xt, Xv, Xs


def best_thresholds(proba, y):
    best = (-1.0, 0.34, 0.34)
    grid = np.linspace(0.18, 0.62, 45)
    for t0, t2 in itertools.product(grid, grid):
        pred = proba.argmax(axis=1)
        pred[proba[:, 0] >= t0] = 0
        pred[proba[:, 2] >= t2] = 2
        score = f1_score(y, pred, average="macro")
        if score > best[0]:
            best = (score, float(t0), float(t2))
    return best[1], best[2], best[0]


def apply_thresholds(proba, thresholds):
    t0, t2 = thresholds
    pred = proba.argmax(axis=1)
    pred[proba[:, 0] >= t0] = 0
    pred[proba[:, 2] >= t2] = 2
    return pred


def train_one(X_train, y_train, X_val, y_val, config, seed):
    set_seed(seed)
    model = MLP(X_train.shape[1], config["hidden"], config["dropout"]).to(DEVICE)
    counts = np.bincount(y_train, minlength=3).astype(float)
    weights = counts.sum() / np.maximum(counts, 1.0)
    weights = torch.tensor(weights / weights.mean(), dtype=torch.float32, device=DEVICE)
    loss_fn = nn.CrossEntropyLoss(weight=weights, label_smoothing=config["label_smoothing"])
    opt = torch.optim.AdamW(model.parameters(), lr=config["lr"], weight_decay=config["weight_decay"])
    train_ds = TensorDataset(torch.tensor(X_train), torch.tensor(y_train, dtype=torch.long))
    loader = DataLoader(train_ds, batch_size=config["batch_size"], shuffle=True, drop_last=False)
    Xv = torch.tensor(X_val, device=DEVICE)
    best_state = None
    best_f1 = -1.0
    patience = 40
    wait = 0
    for epoch in range(500):
        model.train()
        for xb, yb in loader:
            xb = xb.to(DEVICE)
            yb = yb.to(DEVICE)
            opt.zero_grad(set_to_none=True)
            loss = loss_fn(model(xb), yb)
            loss.backward()
            opt.step()
        if epoch % 2 == 0:
            model.eval()
            with torch.no_grad():
                proba = torch.softmax(model(Xv), dim=1).cpu().numpy()
            pred = proba.argmax(axis=1)
            score = f1_score(y_val, pred, average="macro")
            if score > best_f1:
                best_f1 = score
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                wait = 0
            else:
                wait += 1
            if wait >= patience:
                break
    model.load_state_dict(best_state)
    return model, best_f1


def evaluate_config(X, y, config, selector, dataset_name):
    outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    pred_argmax = np.zeros(len(y), dtype=int)
    pred_thresh = np.zeros(len(y), dtype=int)
    fold_val_f1 = []
    thresholds_used = []
    for fold, (train_val_idx, test_idx) in enumerate(outer.split(X, y), start=1):
        train_idx, val_idx = train_test_split(
            train_val_idx,
            test_size=0.2,
            stratify=y[train_val_idx],
            random_state=RANDOM_STATE + fold,
        )
        X_train, X_val, X_test = preprocess_fit_transform(
            X.iloc[train_idx], y[train_idx], X.iloc[val_idx], X.iloc[test_idx], selector
        )
        val_probas = []
        test_probas = []
        seed_base = config["seed"] + fold * 100
        for ens in range(config["ensemble"]):
            model, val_f1 = train_one(X_train, y[train_idx], X_val, y[val_idx], config, seed_base + ens)
            fold_val_f1.append(val_f1)
            model.eval()
            with torch.no_grad():
                val_probas.append(torch.softmax(model(torch.tensor(X_val, device=DEVICE)), dim=1).cpu().numpy())
                test_probas.append(torch.softmax(model(torch.tensor(X_test, device=DEVICE)), dim=1).cpu().numpy())
        val_proba = np.mean(val_probas, axis=0)
        test_proba = np.mean(test_probas, axis=0)
        thresholds = best_thresholds(val_proba, y[val_idx])[:2]
        thresholds_used.append(thresholds)
        pred_argmax[test_idx] = test_proba.argmax(axis=1)
        pred_thresh[test_idx] = apply_thresholds(test_proba, thresholds)
    rows = []
    for mode, pred in [("argmax", pred_argmax), ("fold_val_threshold", pred_thresh)]:
        rows.append({
            "dataset": dataset_name,
            "selector": selector,
            "mode": mode,
            "hidden": str(config["hidden"]),
            "dropout": config["dropout"],
            "lr": config["lr"],
            "weight_decay": config["weight_decay"],
            "label_smoothing": config["label_smoothing"],
            "batch_size": config["batch_size"],
            "ensemble": config["ensemble"],
            "mean_inner_val_f1": float(np.mean(fold_val_f1)),
            "accuracy_3": accuracy_score(y, pred),
            "balanced_accuracy_3": balanced_accuracy_score(y, pred),
            "macro_f1_3": f1_score(y, pred, average="macro"),
            "thresholds": str(thresholds_used),
        })
    return rows, pred_argmax, pred_thresh


def main():
    print(f"device={DEVICE}")
    datasets, y_score, y = build_features()
    configs = []
    for hidden in [(32,), (64,), (96,), (64, 32), (128, 64)]:
        for dropout in [0.15, 0.3, 0.45]:
            for lr in [3e-4, 8e-4, 1.5e-3]:
                configs.append({
                    "hidden": hidden,
                    "dropout": dropout,
                    "lr": lr,
                    "weight_decay": 1e-3,
                    "label_smoothing": 0.03,
                    "batch_size": 64,
                    "ensemble": 3,
                    "seed": RANDOM_STATE,
                })
    selectors = ["all", "mi30", "mi40", "mi60", "f30", "f40", "f60"]
    rows = []
    best = (-1.0, None)
    pred_df = pd.DataFrame({"Empathy_Score": y_score, "true_3class": y + 1})
    for dataset_name, X in datasets.items():
        for selector in selectors:
            if selector != "all" and int(selector[2:]) >= X.shape[1]:
                continue
            for i, config in enumerate(configs, start=1):
                out_rows, pred_argmax, pred_thresh = evaluate_config(X, y, config, selector, dataset_name)
                rows.extend(out_rows)
                local_best = max(out_rows, key=lambda r: r["macro_f1_3"])
                if local_best["macro_f1_3"] > best[0]:
                    best = (local_best["macro_f1_3"], local_best)
                    pred_df["best_argmax"] = pred_argmax + 1
                    pred_df["best_threshold"] = pred_thresh + 1
                    print("NEW_BEST", best[0], local_best, flush=True)
                if best[0] >= 0.55:
                    print("Reached target 0.55; stopping early.", flush=True)
                    break
            if best[0] >= 0.55:
                break
        if best[0] >= 0.55:
            break
    out = pd.DataFrame(rows).sort_values(["macro_f1_3", "balanced_accuracy_3"], ascending=False)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUT_DIR / "teacher_3class_gpu_mlp_tuning_results.csv"
    pred_path = OUT_DIR / "teacher_3class_gpu_mlp_best_predictions.csv"
    out.to_csv(out_path, index=False)
    pred_df.to_csv(pred_path, index=False)
    print("Top GPU MLP candidates:")
    print(out.head(20).to_string(index=False))
    print(f"Saved: {out_path}")
    print(f"Saved: {pred_path}")


if __name__ == "__main__":
    main()

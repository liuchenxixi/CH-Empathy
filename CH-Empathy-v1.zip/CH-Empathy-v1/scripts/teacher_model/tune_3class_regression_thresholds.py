
from __future__ import annotations

import itertools
import warnings
import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr
from sklearn.base import clone
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.feature_selection import SelectKBest, f_regression, mutual_info_regression
from sklearn.impute import SimpleImputer
from sklearn.linear_model import ElasticNet, Ridge
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR, LinearSVR

from compare_reduced_feature_teachers import DOMAIN_GROUPS, domain_aggregates, load_seed_semantic, semantic_numeric
from shared import OUT_DIR, apply_bins, load_seed_onehot, load_seed_scores, quantile_bins

warnings.filterwarnings("ignore")
RANDOM_STATE = 42


def build_datasets():
    _, _, y_score, _ = load_seed_onehot()
    seed_sem = load_seed_semantic(load_seed_scores())
    X_sem = semantic_numeric(seed_sem)
    X_domain = domain_aggregates(seed_sem)
    X_plus = pd.concat([X_sem, X_domain], axis=1)
    datasets = {"semantic_numeric": X_sem, "semantic_plus_domain": X_plus, "domain_aggregated": X_domain}
    for group, cols in DOMAIN_GROUPS.items():
        drop = set(cols + [f"{c}_missing" for c in cols])
        keep = [c for c in X_sem.columns if c not in drop]
        datasets[f"semantic_no_{group}"] = X_sem[keep]
    y_3 = np.asarray(apply_bins(y_score, quantile_bins(y_score, 3)), dtype=int) - 1
    return datasets, y_score.to_numpy(float), y_3


def make_pipe(model, selector="none", scale=True):
    steps = [("imputer", SimpleImputer(strategy="median"))]
    if selector.startswith("mi"):
        steps.append(("select", SelectKBest(mutual_info_regression, k=int(selector[2:]))))
    elif selector.startswith("f"):
        steps.append(("select", SelectKBest(f_regression, k=int(selector[1:]))))
    if scale:
        steps.append(("scaler", StandardScaler()))
    steps.append(("model", model))
    return Pipeline(steps)


def model_grid():
    models = {}
    for alpha in [0.3, 1, 3, 10, 30, 100]:
        models[f"ridge_a{alpha}"] = (Ridge(alpha=alpha), True)
    for alpha in [0.01, 0.03, 0.05, 0.08, 0.12, 0.2]:
        for l1 in [0.05, 0.2, 0.5, 0.8]:
            models[f"enet_a{alpha}_l1{l1}"] = (ElasticNet(alpha=alpha, l1_ratio=l1, max_iter=20000), True)
    for C in [0.3, 0.7, 1.0, 2.0, 4.0]:
        for eps in [0.2, 0.5, 0.8, 1.2]:
            models[f"linear_svr_C{C}_e{eps}"] = (LinearSVR(C=C, epsilon=eps, random_state=RANDOM_STATE, max_iter=30000), True)
    for C in [0.5, 1.0, 2.0, 4.0, 8.0]:
        for gamma in ["scale", 0.005, 0.01, 0.02, 0.04]:
            models[f"rbf_svr_C{C}_g{gamma}"] = (SVR(C=C, gamma=gamma, kernel="rbf"), True)
    for lr in [0.02, 0.04, 0.06]:
        for leaf in [5, 9, 15]:
            models[f"hgb_lr{lr}_leaf{leaf}"] = (HistGradientBoostingRegressor(learning_rate=lr, max_iter=220, max_leaf_nodes=leaf, l2_regularization=1.0, random_state=RANDOM_STATE), False)
    models["rf_shallow"] = (RandomForestRegressor(n_estimators=400, max_depth=6, min_samples_leaf=6, max_features="sqrt", random_state=RANDOM_STATE, n_jobs=-1), False)
    models["extra_shallow"] = (ExtraTreesRegressor(n_estimators=400, max_depth=6, min_samples_leaf=6, max_features="sqrt", random_state=RANDOM_STATE, n_jobs=-1), False)
    return models


def best_cutoffs(pred, y):
    lo, hi = np.percentile(pred, [10, 90])
    grid = np.linspace(lo, hi, 80)
    best = (-1, None, None)
    for c1, c2 in itertools.combinations(grid, 2):
        cls = np.digitize(pred, [c1, c2])
        score = f1_score(y, cls, average="macro")
        if score > best[0]:
            best = (score, float(c1), float(c2))
    return best[1], best[2], best[0]


def eval_nested(X, y_score, y_3, est):
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    pred_score = np.zeros(len(y_score))
    pred_default = np.zeros(len(y_3), dtype=int)
    pred_tuned = np.zeros(len(y_3), dtype=int)
    default_bins = quantile_bins(pd.Series(y_score), 3)
    val_f1s = []
    cutoffs = []
    for fold, (train_val, test) in enumerate(cv.split(X, y_3), start=1):
        train, val = train_test_split(train_val, test_size=0.22, stratify=y_3[train_val], random_state=RANDOM_STATE + fold)
        m = clone(est).fit(X.iloc[train], y_score[train])
        val_pred = m.predict(X.iloc[val])
        test_pred = m.predict(X.iloc[test])
        c1, c2, vf1 = best_cutoffs(val_pred, y_3[val])
        val_f1s.append(vf1)
        cutoffs.append((c1, c2))
        pred_score[test] = test_pred
        pred_default[test] = np.asarray(apply_bins(test_pred, default_bins), dtype=int) - 1
        pred_tuned[test] = np.digitize(test_pred, [c1, c2])
    return pred_score, pred_default, pred_tuned, val_f1s, cutoffs


def corr(fn, a, b):
    if np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(fn(a, b).statistic)


def main():
    datasets, y_score, y_3 = build_datasets()
    models = model_grid()
    selectors = ["none", "mi20", "mi30", "mi40", "mi60", "f20", "f30", "f40", "f60"]
    rows = []
    best = -1
    best_pred = None
    checked = 0
    for dname in ["semantic_numeric", "semantic_plus_domain", "semantic_no_spouse", "semantic_no_parents", "semantic_no_demographic", "semantic_no_belief_public", "semantic_no_media_leisure", "domain_aggregated"]:
        X = datasets[dname]
        for sel in selectors:
            if sel != "none" and int(sel[2:]) >= X.shape[1]:
                continue
            for mname, (model, scale) in models.items():
                est = make_pipe(model, sel, scale=scale)
                try:
                    pred_score, pred_default, pred_tuned, val_f1s, cutoffs = eval_nested(X, y_score, y_3, est)
                except Exception:
                    continue
                for mode, pred_cls in [("default_score_bins", pred_default), ("nested_val_cutoffs", pred_tuned)]:
                    row = {
                        "dataset": dname,
                        "n_features": X.shape[1],
                        "selector": sel,
                        "model": mname,
                        "mode": mode,
                        "accuracy_3": accuracy_score(y_3, pred_cls),
                        "balanced_accuracy_3": balanced_accuracy_score(y_3, pred_cls),
                        "macro_f1_3": f1_score(y_3, pred_cls, average="macro"),
                        "mae": mean_absolute_error(y_score, pred_score),
                        "rmse": mean_squared_error(y_score, pred_score) ** 0.5,
                        "pearson_r": corr(pearsonr, y_score, pred_score),
                        "spearman_rho": corr(spearmanr, y_score, pred_score),
                        "mean_inner_val_f1": float(np.mean(val_f1s)),
                        "cutoffs": str(cutoffs),
                    }
                    rows.append(row)
                    if row["macro_f1_3"] > best:
                        best = row["macro_f1_3"]
                        best_pred = pred_cls.copy()
                        print("NEW_BEST", best, row, flush=True)
                    if best >= 0.55:
                        print("Reached target 0.55; stopping early.", flush=True)
                        break
                checked += 1
                if checked % 50 == 0:
                    print("checked", checked, "best", best, flush=True)
                if best >= 0.55:
                    break
            if best >= 0.55:
                break
        if best >= 0.55:
            break
    out = pd.DataFrame(rows).sort_values(["macro_f1_3", "spearman_rho"], ascending=False)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUT_DIR / "teacher_3class_regression_threshold_results.csv"
    pred_path = OUT_DIR / "teacher_3class_regression_threshold_best_predictions.csv"
    out.to_csv(out_path, index=False)
    pd.DataFrame({"Empathy_Score": y_score, "true_3class": y_3+1, "pred_3class": best_pred+1}).to_csv(pred_path, index=False)
    print("Top regression-threshold candidates:")
    print(out.head(30).to_string(index=False))
    print(f"Saved: {out_path}")
    print(f"Saved: {pred_path}")

if __name__ == "__main__":
    main()

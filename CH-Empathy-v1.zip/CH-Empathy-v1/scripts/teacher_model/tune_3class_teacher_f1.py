from __future__ import annotations

import itertools
import sys
import warnings
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.ensemble import (
    ExtraTreesClassifier,
    GradientBoostingClassifier,
    HistGradientBoostingClassifier,
    RandomForestClassifier,
    VotingClassifier,
)
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC, SVC

from compare_reduced_feature_teachers import DOMAIN_GROUPS, domain_aggregates, load_seed_semantic, semantic_numeric
from shared import OUT_DIR, apply_bins, load_seed_onehot, load_seed_scores, quantile_bins


warnings.filterwarnings("ignore")

RANDOM_STATE = 42
N_SPLITS = 5


@dataclass(frozen=True)
class Candidate:
    dataset: str
    selector: str
    model: str
    estimator: BaseEstimator


class ProbabilityThresholdClassifier(BaseEstimator, ClassifierMixin):
    """Wrap a probabilistic classifier and choose class cutoffs on the training fold."""

    def __init__(self, base_estimator=None, grid_size: int = 41):
        self.base_estimator = base_estimator
        self.grid_size = grid_size

    def fit(self, X, y):
        y = np.asarray(y).astype(int)
        self.classes_ = np.array([1, 2, 3])
        self.model_ = clone(self.base_estimator)
        self.model_.fit(X, y)
        proba = self.model_.predict_proba(X)
        self.thresholds_ = self._best_thresholds(proba, y)
        return self

    def _best_thresholds(self, proba, y):
        best = (-1.0, 0.34, 0.34)
        grid = np.linspace(0.2, 0.6, self.grid_size)
        for t1, t3 in itertools.product(grid, grid):
            pred = np.argmax(proba, axis=1) + 1
            pred[proba[:, 0] >= t1] = 1
            pred[proba[:, 2] >= t3] = 3
            score = f1_score(y, pred, average="macro")
            if score > best[0]:
                best = (score, float(t1), float(t3))
        return best[1], best[2]

    def predict(self, X):
        proba = self.model_.predict_proba(X)
        pred = np.argmax(proba, axis=1) + 1
        t1, t3 = self.thresholds_
        pred[proba[:, 0] >= t1] = 1
        pred[proba[:, 2] >= t3] = 3
        return pred


def make_pipeline(model, selector: str = "none") -> Pipeline:
    steps = [("imputer", SimpleImputer(strategy="median"))]
    if selector.startswith("mi"):
        steps.append(("select", SelectKBest(mutual_info_classif, k=int(selector[2:]))))
    elif selector.startswith("f"):
        steps.append(("select", SelectKBest(f_classif, k=int(selector[1:]))))
    steps.append(("scaler", StandardScaler()))
    steps.append(("model", model))
    return Pipeline(steps)


def model_grid() -> dict[str, BaseEstimator]:
    models: dict[str, BaseEstimator] = {}
    for c in [0.03, 0.1, 0.3, 1.0, 3.0]:
        models[f"logit_bal_C{c}"] = LogisticRegression(C=c, class_weight="balanced", max_iter=5000, solver="lbfgs")
        models[f"logit_C{c}"] = LogisticRegression(C=c, max_iter=5000, solver="lbfgs")
        models[f"ridge_cls_C{c}"] = RidgeClassifier(alpha=1.0 / c, class_weight="balanced")
        models[f"linsvc_C{c}"] = LinearSVC(C=c, class_weight="balanced", max_iter=20000, random_state=RANDOM_STATE)

    for c in [0.3, 1.0, 3.0]:
        for gamma in ["scale", 0.03]:
            models[f"rbf_svc_C{c}_g{gamma}"] = SVC(
                C=c,
                gamma=gamma,
                kernel="rbf",
                class_weight="balanced",
                probability=False,
                random_state=RANDOM_STATE,
            )

    for depth in [2, 3, 4]:
        for leaf in [5, 8, 12]:
            name = f"extra_trees_d{depth}_leaf{leaf}"
            models[name] = ExtraTreesClassifier(
                n_estimators=300,
                max_depth=depth,
                min_samples_leaf=leaf,
                max_features="sqrt",
                class_weight="balanced",
                random_state=RANDOM_STATE,
                n_jobs=-1,
            )
            models[f"rf_d{depth}_leaf{leaf}"] = RandomForestClassifier(
                n_estimators=300,
                max_depth=depth,
                min_samples_leaf=leaf,
                max_features="sqrt",
                class_weight="balanced",
                random_state=RANDOM_STATE,
                n_jobs=-1,
            )

    for lr in [0.02, 0.04]:
        for leaf_nodes in [5, 9, 15]:
            models[f"hgb_lr{lr}_leaf{leaf_nodes}"] = HistGradientBoostingClassifier(
                learning_rate=lr,
                max_iter=250,
                max_leaf_nodes=leaf_nodes,
                l2_regularization=1.0,
                random_state=RANDOM_STATE,
            )

    models["lda"] = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
    models["qda_reg0.2"] = QuadraticDiscriminantAnalysis(reg_param=0.2)
    models["qda_reg0.5"] = QuadraticDiscriminantAnalysis(reg_param=0.5)
    models["gaussian_nb"] = GaussianNB()
    models["gb_depth2"] = GradientBoostingClassifier(max_depth=2, n_estimators=120, learning_rate=0.04, random_state=RANDOM_STATE)
    models["gb_depth3"] = GradientBoostingClassifier(max_depth=3, n_estimators=100, learning_rate=0.04, random_state=RANDOM_STATE)

    prob_logit = LogisticRegression(C=0.3, class_weight="balanced", max_iter=5000, solver="lbfgs")
    models["logit_threshold_C0.3"] = ProbabilityThresholdClassifier(prob_logit)
    return models


def build_datasets() -> tuple[dict[str, pd.DataFrame], pd.Series, np.ndarray]:
    X_onehot, _, y_score, _ = load_seed_onehot()
    seed_sem = load_seed_semantic(load_seed_scores())
    X_sem = semantic_numeric(seed_sem)
    X_domain = domain_aggregates(seed_sem)
    X_plus = pd.concat([X_sem, X_domain], axis=1)

    datasets = {
        "semantic_numeric": X_sem,
        "semantic_plus_domain": X_plus,
        "domain_aggregated": X_domain,
    }

    # Leave-one-domain-out sets. These are interpretable manual feature reductions.
    for group_name, cols in DOMAIN_GROUPS.items():
        drop_cols = cols + [f"{col}_missing" for col in cols]
        keep = [col for col in X_sem.columns if col not in drop_cols]
        datasets[f"semantic_no_{group_name}"] = X_sem[keep]

    compact_groups = [
        "wellbeing_health",
        "education_work",
        "hukou_resource",
        "class_mobility",
        "family_marriage",
        "media_leisure",
        "belief_public",
    ]
    compact_cols = []
    for group in compact_groups:
        compact_cols.extend(DOMAIN_GROUPS[group])
    compact_cols = [col for col in compact_cols if col in X_sem.columns]
    compact_cols += [f"{col}_missing" for col in compact_cols if f"{col}_missing" in X_sem.columns]
    datasets["semantic_compact_no_spouse_parents_demo"] = X_sem[compact_cols]

    bins_3 = quantile_bins(y_score, 3)
    y_3 = np.asarray(apply_bins(y_score, bins_3), dtype=int)
    return datasets, y_score, y_3


def evaluate_candidate(X: pd.DataFrame, y: np.ndarray, estimator: BaseEstimator) -> tuple[np.ndarray, dict]:
    cv = StratifiedKFold(n_splits=N_SPLITS, shuffle=True, random_state=RANDOM_STATE)
    pred = np.zeros(len(y), dtype=int)
    for train_idx, test_idx in cv.split(X, y):
        model = clone(estimator)
        model.fit(X.iloc[train_idx], y[train_idx])
        pred[test_idx] = model.predict(X.iloc[test_idx])
    return pred, {
        "accuracy_3": accuracy_score(y, pred),
        "balanced_accuracy_3": balanced_accuracy_score(y, pred),
        "macro_f1_3": f1_score(y, pred, average="macro"),
    }


def main() -> None:
    datasets, y_score, y_3 = build_datasets()
    models = model_grid()
    rows = []
    predictions = pd.DataFrame({"Empathy_Score": y_score, "true_3class": y_3})

    for dataset_name, X in datasets.items():
        selectors = ["none"]
        if X.shape[1] >= 15:
            selectors += [f"mi{k}" for k in [12, 20, 30, 40] if k < X.shape[1]]
            selectors += [f"f{k}" for k in [12, 20, 30, 40] if k < X.shape[1]]
        for selector in selectors:
            for model_name, model in models.items():
                estimator = make_pipeline(model, selector)
                try:
                    pred, metrics = evaluate_candidate(X, y_3, estimator)
                except Exception as exc:
                    rows.append(
                        {
                            "dataset": dataset_name,
                            "n_features": X.shape[1],
                            "selector": selector,
                            "model": model_name,
                            "error": str(exc)[:160],
                        }
                    )
                    continue
                row = {
                    "dataset": dataset_name,
                    "n_features": X.shape[1],
                    "selector": selector,
                    "model": model_name,
                    "error": "",
                    **metrics,
                }
                rows.append(row)
                key = f"{dataset_name}__{selector}__{model_name}"
                if metrics["macro_f1_3"] >= 0.53:
                    predictions[key] = pred

    results = pd.DataFrame(rows)
    ok = results[results["error"].fillna("").eq("")].copy()
    ok = ok.sort_values(["macro_f1_3", "balanced_accuracy_3", "accuracy_3"], ascending=False)
    failed = results[~results["error"].fillna("").eq("")]
    out_dir = OUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "teacher_3class_f1_tuning_results.csv"
    pred_path = out_dir / "teacher_3class_f1_tuning_predictions.csv"
    ok.to_csv(out_path, index=False)
    predictions.to_csv(pred_path, index=False)
    if not failed.empty:
        failed.to_csv(out_dir / "teacher_3class_f1_tuning_failed.csv", index=False)

    print("Top candidates by three-level macro-F1:")
    print(
        ok[
            [
                "dataset",
                "n_features",
                "selector",
                "model",
                "macro_f1_3",
                "balanced_accuracy_3",
                "accuracy_3",
            ]
        ]
        .head(30)
        .to_string(index=False)
    )
    print(f"\nSaved: {out_path}")
    print(f"Saved predictions for candidates >= 0.53 F1: {pred_path}")


if __name__ == "__main__":
    main()

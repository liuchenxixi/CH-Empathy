from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import mutual_info_regression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold

from shared import apply_bins, ensure_out_dir, load_cgss2023_onehot, load_seed_onehot, quantile_bins


FEATURE_BUDGETS = [20, 30, 50, 80, "all"]


def make_model() -> RandomForestRegressor:
    return RandomForestRegressor(
        n_estimators=500,
        max_depth=12,
        min_samples_leaf=3,
        random_state=42,
        n_jobs=-1,
    )


def select_mi_features(X_train: pd.DataFrame, y_train: pd.Series, budget: int | str) -> list[str]:
    if budget == "all" or int(budget) >= X_train.shape[1]:
        return list(X_train.columns)
    discrete = np.array([pd.Series(X_train[col]).dropna().nunique() <= 20 for col in X_train.columns])
    scores = mutual_info_regression(X_train, y_train, discrete_features=discrete, random_state=42)
    return list(pd.Series(scores, index=X_train.columns).sort_values(ascending=False, kind="mergesort").head(int(budget)).index)


def metric_row(budget, fold, feature_count, y_true, y_pred, bins_3, bins_5):
    truth = pd.Series(np.asarray(y_true, dtype=float)).reset_index(drop=True)
    pred = pd.Series(np.asarray(y_pred, dtype=float)).reset_index(drop=True)
    true_3, pred_3 = apply_bins(truth, bins_3), apply_bins(pred, bins_3)
    true_5, pred_5 = apply_bins(truth, bins_5), apply_bins(pred, bins_5)
    return {
        "budget": budget,
        "fold": fold,
        "feature_count": feature_count,
        "MAE": float(mean_absolute_error(truth, pred)),
        "RMSE": float(np.sqrt(mean_squared_error(truth, pred))),
        "R2": float(r2_score(truth, pred)),
        "Spearman": float(truth.corr(pred, method="spearman")),
        "acc_3": float(accuracy_score(true_3, pred_3)),
        "bal_acc_3": float(balanced_accuracy_score(true_3, pred_3)),
        "macro_f1_3": float(f1_score(true_3, pred_3, average="macro")),
        "acc_5": float(accuracy_score(true_5, pred_5)),
        "bal_acc_5": float(balanced_accuracy_score(true_5, pred_5)),
        "macro_f1_5": float(f1_score(true_5, pred_5, average="macro")),
    }


def main() -> None:
    out_dir = ensure_out_dir()
    X_seed, _y_level_5, y_score, feature_cols = load_seed_onehot()
    row_ids, X_cgss2023, _features = load_cgss2023_onehot()
    bins_3 = quantile_bins(y_score, q=3)
    bins_5 = quantile_bins(y_score, q=5)

    rows = []
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    for budget in FEATURE_BUDGETS:
        print(f"\nRunning budget={budget}...")
        for fold, (train_idx, valid_idx) in enumerate(kf.split(X_seed), start=1):
            X_train, y_train = X_seed.iloc[train_idx], y_score.iloc[train_idx]
            X_valid, y_valid = X_seed.iloc[valid_idx], y_score.iloc[valid_idx]
            selected = select_mi_features(X_train, y_train, budget)
            model = make_model()
            model.fit(X_train[selected], y_train)
            pred = model.predict(X_valid[selected])
            row = metric_row(budget, fold, len(selected), y_valid, pred, bins_3, bins_5)
            rows.append(row)
            print(
                f"fold {fold}: features={len(selected)}, RMSE={row['RMSE']:.4f}, "
                f"R2={row['R2']:.4f}, Spearman={row['Spearman']:.4f}, "
                f"macro_F1_3={row['macro_f1_3']:.4f}, macro_F1_5={row['macro_f1_5']:.4f}"
            )

    results = pd.DataFrame(rows)
    summary = (
        results.groupby("budget", sort=False)
        .agg(
            feature_count=("feature_count", "mean"),
            MAE=("MAE", "mean"),
            RMSE=("RMSE", "mean"),
            R2=("R2", "mean"),
            Spearman=("Spearman", "mean"),
            acc_3=("acc_3", "mean"),
            bal_acc_3=("bal_acc_3", "mean"),
            macro_f1_3=("macro_f1_3", "mean"),
            acc_5=("acc_5", "mean"),
            bal_acc_5=("bal_acc_5", "mean"),
            macro_f1_5=("macro_f1_5", "mean"),
        )
        .reset_index()
    )
    results.to_csv(out_dir / "teacher_mi_regression_cv_results.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(out_dir / "teacher_mi_regression_cv_summary.csv", index=False, encoding="utf-8-sig")

    best = summary.sort_values(by=["macro_f1_3", "Spearman", "RMSE"], ascending=[False, False, True], kind="mergesort").iloc[0]
    best_budget = best["budget"]
    final_features = select_mi_features(X_seed, y_score, best_budget)
    mi_scores = pd.Series(
        mutual_info_regression(
            X_seed,
            y_score,
            discrete_features=np.array([pd.Series(X_seed[col]).dropna().nunique() <= 20 for col in X_seed.columns]),
            random_state=42,
        ),
        index=feature_cols,
    ).sort_values(ascending=False, kind="mergesort")
    pd.DataFrame(
        {"feature": mi_scores.index, "mutual_info": mi_scores.values, "selected": mi_scores.index.isin(final_features)}
    ).to_csv(out_dir / "teacher_mi_regression_selected_features.csv", index=False, encoding="utf-8-sig")

    final_model = make_model()
    final_model.fit(X_seed[final_features], y_score)
    preds = final_model.predict(X_cgss2023[final_features])
    tree_preds = np.vstack([tree.predict(X_cgss2023[final_features].to_numpy()) for tree in final_model.estimators_])
    uncertainty = tree_preds.std(axis=0)
    joblib.dump(
        {
            "model": final_model,
            "selected_features": final_features,
            "best_budget": best_budget,
            "bins_3": bins_3,
            "bins_5": bins_5,
            "target": "IRI_total_score",
        },
        out_dir / "teacher_random_forest_mi_score_regressor.joblib",
    )

    pseudo = pd.DataFrame(
        {
            "cgss2023_row_id": row_ids,
            "Empathy_Score_Pred": preds,
            "Empathy_Score_Uncertainty": uncertainty,
            "Empathy_Level_3": apply_bins(preds, bins_3),
            "Empathy_Level_5": apply_bins(preds, bins_5),
        }
    )
    pseudo.to_csv(out_dir / "CGSS2023_Pseudo_Labeled_mi_score_regression.csv", index=False, encoding="utf-8-sig")

    print("\nsummary:")
    print(summary.to_string(index=False))
    print(f"\nBest budget by macro_F1_3: {best_budget}")
    print("\nCGSS2023 derived 3-class distribution:")
    print(pseudo["Empathy_Level_3"].value_counts().sort_index())
    print("\nCGSS2023 derived 5-class distribution:")
    print(pseudo["Empathy_Level_5"].value_counts().sort_index())
    print(f"\noutputs saved in: {out_dir}")


if __name__ == "__main__":
    main()

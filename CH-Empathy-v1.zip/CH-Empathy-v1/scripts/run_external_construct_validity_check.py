
import os
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, kruskal

ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
SOURCE = Path(os.environ.get("CGSS2023_DTA", PROJECT_ROOT / "data" / "CGSS2023.dta"))
if not SOURCE.exists():
    raise FileNotFoundError(
        "CGSS2023 raw data are not included in this release. "
        "Set CGSS2023_DTA=/path/to/CGSS2023.dta before running this script."
    )
OUT_DIR = PROJECT_ROOT / "results_construct_validity"
OUT_DIR.mkdir(exist_ok=True)

WEAK_PATH = PROJECT_ROOT / "data" / "CGSS2023_Pseudo_Labeled_mi_internal_3class.csv"
weak = pd.read_csv(WEAK_PATH)

cols = [
    "a33", "a34", "b5", "b6", "c15d", "c15f", "c17a", "c17b", "c17c",
    "c17e", "c19", "b1810", "b1814",
]
raw = pd.read_stata(SOURCE, columns=cols, convert_categoricals=True)
raw.insert(0, "cgss2023_row_id", np.arange(len(raw)))
df = raw.merge(weak, on="cgss2023_row_id", how="inner")

UNKNOWN_TEXT = {"", "nan", "NaN", "不知道", "拒绝回答", "无法回答", "电话调查未调查"}

def text(v):
    if pd.isna(v):
        return "nan"
    return str(v).strip()

def agree5(v):
    t = text(v)
    return {
        "非常不同意": 1, "比较不同意": 2, "说不上同意不同意": 3, "比较同意": 4, "非常同意": 5,
    }.get(t, np.nan)

def agree6(v):
    t = text(v)
    return {
        "非常不同意": 1, "不同意": 2, "有点不同意": 3, "有点同意": 4, "同意": 5, "非常同意": 6,
    }.get(t, np.nan)

def close5(v):
    t = text(v)
    return {"非常不密切": 1, "不密切": 2, "一般": 3, "密切": 4, "非常密切": 5}.get(t, np.nan)

def trust5(v):
    t = text(v)
    return {"非常不信任": 1, "不信任": 2, "一般": 3, "信任": 4, "非常信任": 5}.get(t, np.nan)

def trust4(v):
    t = text(v)
    return {"完全不信任": 1, "不太信任": 2, "比较信任": 3, "非常信任": 4}.get(t, np.nan)

def majority_trust4(v):
    t = text(v)
    return {
        "和大多数人打交道几乎总是需要非常小心": 1,
        "和大多数人打交道通常需要非常小心": 2,
        "大多数人通常是可以信任的": 3,
        "大多数人几乎总是可以信任的": 4,
    }.get(t, np.nan)

def binary_agree(v):
    t = text(v)
    return {"不同意": 0, "同意": 1}.get(t, np.nan)

# These variables are not part of the 49 semantic teacher features used in the paper.
specs = [
    ("a33", "General social trust", agree5),
    ("a34", "Low social exploitation concern", lambda v: 6 - agree5(v) if not np.isnan(agree5(v)) else np.nan),
    ("b6", "Stranger trust", trust5),
    ("c19", "Majority trust", majority_trust4),
    ("c17a", "Trust in relatives", trust4),
    ("c17b", "Trust in friends", trust4),
    ("c17c", "Trust in neighbors", trust4),
    ("c17e", "Trust in strangers", trust4),
    ("b5", "Contact with relatives and friends", close5),
    ("c15f", "Neighbor helpfulness", agree6),
    ("c15d", "Willingness to contribute to society", agree6),
    ("b1810", "Perceived income-distribution fairness", binary_agree),
    ("b1814", "Perceived equal opportunity", binary_agree),
]

score = "Empathy_Score_Pred"
level = "Empathy_Level_3"
rows = []
for col, label, mapper in specs:
    x = df[col].map(mapper).astype(float)
    y = pd.to_numeric(df[score], errors="coerce")
    valid = x.notna() & y.notna()
    if valid.sum() < 50:
        continue
    rho, p = spearmanr(y[valid], x[valid])
    means, ns = [], []
    groups = []
    for lv in [1, 2, 3]:
        vals = x[(df[level] == lv) & x.notna()]
        means.append(vals.mean())
        ns.append(len(vals))
        groups.append(vals.values)
    h, kp = kruskal(*groups) if all(len(g) for g in groups) else (np.nan, np.nan)
    rows.append({
        "variable": col,
        "construct": label,
        "n": int(valid.sum()),
        "spearman_rho": rho,
        "p_value": p,
        "level1_mean": means[0],
        "level2_mean": means[1],
        "level3_mean": means[2],
        "level1_n": ns[0],
        "level2_n": ns[1],
        "level3_n": ns[2],
        "kruskal_p": kp,
    })

res = pd.DataFrame(rows)
res["abs_rho"] = res["spearman_rho"].abs()
res = res.sort_values("abs_rho", ascending=False)
res.to_csv(OUT_DIR / "external_construct_validity.csv", index=False)

paper_vars = ["a33", "b6", "c19", "c17b", "c17c", "b5", "c15f", "c15d", "b1810", "b1814"]
paper = res.set_index("variable").loc[[v for v in paper_vars if v in set(res["variable"])]].reset_index()
paper = paper[["construct", "n", "spearman_rho", "p_value", "level1_mean", "level2_mean", "level3_mean", "kruskal_p"]]
paper.to_csv(OUT_DIR / "external_construct_validity_paper_table.csv", index=False)

print("Saved:", OUT_DIR / "external_construct_validity.csv")
print("Saved:", OUT_DIR / "external_construct_validity_paper_table.csv")
print("\nPaper table candidates:")
for _, r in paper.iterrows():
    print(f"{r['construct']}: n={int(r['n'])}, rho={r['spearman_rho']:.3f}, p={r['p_value']:.2e}, means L1/L2/L3={r['level1_mean']:.2f}/{r['level2_mean']:.2f}/{r['level3_mean']:.2f}, KW p={r['kruskal_p']:.2e}")
print("\nAll external checks sorted by |rho|:")
for _, r in res.iterrows():
    print(f"{r['construct']}: rho={r['spearman_rho']:.3f}, p={r['p_value']:.2e}, n={int(r['n'])}")

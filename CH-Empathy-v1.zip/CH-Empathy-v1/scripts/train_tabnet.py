from __future__ import annotations

import json
import random
import warnings
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import torch
from pytorch_tabnet.tab_model import TabNetClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split


warnings.filterwarnings("ignore", category=FutureWarning)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(__file__).resolve().parent / "data"
RESULT_DIR = Path(__file__).resolve().parent / "results_mi_internal_3class"
FEATURE_COLUMNS_PATH = PROJECT_ROOT / "process" / "data" / "new_schema" / "onehot_feature_columns.json"
INPUT_PATH = DATA_DIR / "cgss2023_onehot_mi_internal_3class.csv"


def set_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_data() -> tuple[np.ndarray, np.ndarray, list[str]]:
    feature_cols = json.loads(FEATURE_COLUMNS_PATH.read_text(encoding="utf-8"))
    df = pd.read_csv(INPUT_PATH)
    X = df[feature_cols].astype(np.float32).values
    y = (pd.to_numeric(df["Empathy_Level_3"], errors="coerce").astype(int).values - 1).astype(np.int64)
    return X, y, feature_cols


def save_outputs(clf: TabNetClassifier, X_test: np.ndarray, y_test: np.ndarray, preds: np.ndarray, feature_cols: list[str]) -> None:
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    y_true = y_test + 1
    y_pred = preds + 1
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_micro": f1_score(y_true, y_pred, average="micro", zero_division=0),
        "precision_weighted": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "recall_weighted": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "f1_weighted": f1_score(y_true, y_pred, average="weighted", zero_division=0),
    }
    pd.DataFrame([metrics]).to_csv(RESULT_DIR / "tabnet_mi_internal_3class_metrics.csv", index=False, encoding="utf-8-sig")
    report = classification_report(y_true, y_pred, labels=[1, 2, 3], digits=4, zero_division=0)
    (RESULT_DIR / "tabnet_mi_internal_3class_classification_report.txt").write_text(report, encoding="utf-8")
    cm = confusion_matrix(y_true, y_pred, labels=[1, 2, 3])
    pd.DataFrame(cm, index=[1, 2, 3], columns=[1, 2, 3]).to_csv(RESULT_DIR / "tabnet_mi_internal_3class_confusion_matrix.csv", encoding="utf-8-sig")

    importance = pd.DataFrame({"feature": feature_cols, "importance": clf.feature_importances_}).sort_values("importance", ascending=False, kind="mergesort")
    importance.to_csv(RESULT_DIR / "tabnet_mi_internal_3class_feature_importance.csv", index=False, encoding="utf-8-sig")
    top15 = importance.head(15)

    plt.figure(figsize=(9, 6))
    plt.barh(top15.iloc[::-1]["feature"], top15.iloc[::-1]["importance"], color="#3274a1")
    plt.xlabel("Importance")
    plt.tight_layout()
    plt.savefig(RESULT_DIR / "tabnet_mi_internal_3class_feature_importance_top15.png", dpi=220)
    plt.close()

    explain_matrix, _masks = clf.explain(X_test)
    explain_df = pd.DataFrame(explain_matrix, columns=feature_cols)
    class_rows = []
    for class_idx in [0, 1, 2]:
        mask = y_test == class_idx
        class_rows.append(explain_df.loc[mask].mean(axis=0) if mask.any() else pd.Series(0.0, index=feature_cols))
    class_explain = pd.DataFrame(class_rows, index=["class_1", "class_2", "class_3"]).T
    class_explain.to_csv(RESULT_DIR / "tabnet_mi_internal_3class_explain_by_class.csv", encoding="utf-8-sig")

    top_features = top15["feature"].tolist()
    for top_n in [5, 10, 15]:
        plt.figure(figsize=(8, max(3.5, top_n * 0.38)))
        sns.heatmap(class_explain.loc[top_features[:top_n]], linewidths=0.8, annot=True, cmap="GnBu", fmt=".5f")
        plt.tight_layout()
        plt.savefig(RESULT_DIR / f"tabnet_mi_internal_3class_explain_top{top_n}.png", dpi=220)
        plt.close()

    print("\nTabNet MI-internal 3-class test metrics:")
    for key, value in metrics.items():
        print(f"{key}: {value:.4f}")
    print("\nclassification report:")
    print(report)


def main() -> None:
    set_seed(42)
    X, y, feature_cols = load_data()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    print(f"train shape: {X_train.shape}, test shape: {X_test.shape}")
    print("train distribution:")
    print(pd.Series(y_train + 1).value_counts().sort_index())
    print("test distribution:")
    print(pd.Series(y_test + 1).value_counts().sort_index())

    clf = TabNetClassifier(
        n_d=32,
        n_a=32,
        n_steps=4,
        gamma=1.5,
        n_independent=2,
        n_shared=2,
        lambda_sparse=1e-4,
        optimizer_fn=torch.optim.Adam,
        optimizer_params=dict(lr=2e-2),
        scheduler_params={"step_size": 50, "gamma": 0.9},
        scheduler_fn=torch.optim.lr_scheduler.StepLR,
        mask_type="entmax",
        seed=42,
        verbose=5,
    )
    clf.fit(
        X_train=X_train,
        y_train=y_train,
        eval_set=[(X_train, y_train), (X_test, y_test)],
        eval_name=["train", "test"],
        eval_metric=["accuracy"],
        max_epochs=60,
        patience=10,
        batch_size=2048,
        virtual_batch_size=128,
        num_workers=0,
        drop_last=False,
        weights=1,
    )
    preds = clf.predict(X_test).astype(int)
    save_outputs(clf, X_test, y_test, preds, feature_cols)
    clf.save_model(str(RESULT_DIR / "tabnet_mi_internal_3class_model"))
    print(f"\nresults saved in: {RESULT_DIR}")


if __name__ == "__main__":
    main()

from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, kruskal

ROOT = Path(__file__).resolve().parent
OUT_DIR = ROOT / "results_construct_validity"
OUT_DIR.mkdir(exist_ok=True)

semantic = pd.read_csv(ROOT / "data" / "cgss2023_semantic.csv")
weak = pd.read_csv(ROOT / "data" / "CGSS2023_Pseudo_Labeled_mi_internal_3class.csv")
df = semantic.merge(weak, on="cgss2023_row_id", how="inner")

score = "Empathy_Score_Pred"
level = "Empathy_Level_3"
unknown = 99

# Variables selected for construct-validity checks. Direction is normalized so
# larger values mean more of the named construct.
specs = {
    "happiness": {"col": "happiness", "label": "Happiness", "transform": "same"},
    "health": {"col": "health", "label": "Self-rated health", "transform": "same"},
    "family_status": {"col": "family_status", "label": "Family economic status", "transform": "same"},
    "socialize": {"col": "socialize", "label": "Social activity frequency", "transform": "same"},
    "relax": {"col": "relax", "label": "Relaxation activity frequency", "transform": "same"},
    "learn": {"col": "learn", "label": "Learning activity frequency", "transform": "same"},
    "entertain_friend": {"col": "entertain_friend", "label": "Friend interaction frequency", "transform": "reverse_1_7"},
    "entertain_neighbor": {"col": "entertain_neighbor", "label": "Neighbor interaction frequency", "transform": "reverse_1_7"},
    "equity": {"col": "equity", "label": "Perceived social fairness", "transform": "same"},
    "Class": {"col": "Class", "label": "Subjective class", "transform": "same"},
    "media_mean_cut": {"col": "media_mean_cut", "label": "Media exposure", "transform": "same"},
    "leisure_mean_cut": {"col": "leisure_mean_cut", "label": "Leisure activity level", "transform": "same"},
    "gender": {"col": "gender", "label": "Gender", "transform": "same"},
    "age_group": {"col": "age_group", "label": "Age group", "transform": "same"},
}

def clean_series(s: pd.Series, transform: str) -> pd.Series:
    x = pd.to_numeric(s, errors="coerce").replace(unknown, np.nan)
    if transform == "reverse_1_7":
        x = 8 - x
    return x

rows = []
trend_rows = []
for name, spec in specs.items():
    x = clean_series(df[spec["col"]], spec["transform"])
    y = pd.to_numeric(df[score], errors="coerce")
    valid = x.notna() & y.notna()
    if valid.sum() < 30:
        continue
    rho, p = spearmanr(y[valid], x[valid])
    # Kruskal-Wallis and group means by weak label level.
    group_values = []
    means = []
    ns = []
    for lv in [1, 2, 3]:
        vals = x[(df[level] == lv) & x.notna()]
        group_values.append(vals.values)
        means.append(vals.mean())
        ns.append(len(vals))
    h, kp = kruskal(*group_values) if all(len(v) > 0 for v in group_values) else (np.nan, np.nan)
    rows.append({
        "variable": name,
        "construct": spec["label"],
        "n": int(valid.sum()),
        "spearman_rho": rho,
        "p_value": p,
        "level1_mean": means[0],
        "level2_mean": means[1],
        "level3_mean": means[2],
        "level1_n": ns[0],
        "level2_n": ns[1],
        "level3_n": ns[2],
        "kruskal_p": kp,
    })

res = pd.DataFrame(rows).sort_values("spearman_rho", ascending=False)
res.to_csv(OUT_DIR / "construct_validity_spearman_and_trends.csv", index=False)

# Also create a compact paper-oriented table with target constructs plus demographic checks.
keep = [
    "happiness", "equity", "socialize", "entertain_friend", "entertain_neighbor",
    "family_status", "health", "gender", "age_group"
]
compact = res.set_index("variable").loc[[k for k in keep if k in set(res["variable"])]].reset_index()
compact = compact[["construct", "n", "spearman_rho", "p_value", "level1_mean", "level2_mean", "level3_mean"]]
compact.to_csv(OUT_DIR / "construct_validity_compact.csv", index=False)

print("Saved:", OUT_DIR / "construct_validity_spearman_and_trends.csv")
print("Saved:", OUT_DIR / "construct_validity_compact.csv")
print("\nCompact construct-validity results:")
for _, r in compact.iterrows():
    print(f"{r['construct']}: n={int(r['n'])}, rho={r['spearman_rho']:.3f}, p={r['p_value']:.2e}, means L1/L2/L3={r['level1_mean']:.2f}/{r['level2_mean']:.2f}/{r['level3_mean']:.2f}")
print("\nAll variables sorted by |rho|:")
tmp = res.assign(abs_rho=res.spearman_rho.abs()).sort_values('abs_rho', ascending=False)
for _, r in tmp.iterrows():
    print(f"{r['construct']}: rho={r['spearman_rho']:.3f}, p={r['p_value']:.2e}, n={int(r['n'])}")

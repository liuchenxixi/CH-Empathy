from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


DATA_DIR = Path(__file__).resolve().parent / "data"
TEACHER_RESULT_DIR = Path(__file__).resolve().parent / "new_schema_teacher" / "results"
PSEUDO_PATH = TEACHER_RESULT_DIR / "CGSS2023_Pseudo_Labeled_mi_score_regression.csv"
ONEHOT_PATH = DATA_DIR / "cgss2023_onehot.csv"
OUT_PSEUDO_PATH = DATA_DIR / "CGSS2023_Pseudo_Labeled_mi_internal_3class.csv"
OUT_ONEHOT_PATH = DATA_DIR / "cgss2023_onehot_mi_internal_3class.csv"


def main() -> None:
    if not PSEUDO_PATH.exists():
        raise FileNotFoundError(f"Missing MI regression pseudo labels: {PSEUDO_PATH}")
    if not ONEHOT_PATH.exists():
        raise FileNotFoundError(f"Missing CGSS2023 onehot features: {ONEHOT_PATH}")

    pseudo = pd.read_csv(PSEUDO_PATH)
    onehot = pd.read_csv(ONEHOT_PATH)
    if len(pseudo) != len(onehot):
        raise ValueError(f"Pseudo rows ({len(pseudo)}) != onehot rows ({len(onehot)})")

    score = pd.to_numeric(pseudo["Empathy_Score_Pred"], errors="coerce")
    if score.isna().any():
        raise ValueError("Empathy_Score_Pred contains missing values")

    internal_level = pd.qcut(score, q=3, labels=[1, 2, 3], duplicates="drop").astype(int)
    if internal_level.nunique() != 3:
        raise ValueError("Internal tertile split did not produce 3 classes")

    bins = np.asarray(pd.qcut(score, q=3, retbins=True, duplicates="drop")[1], dtype=float)
    bins[0] = -np.inf
    bins[-1] = np.inf

    out_pseudo = pseudo.copy()
    out_pseudo["Empathy_Level_3_SeedBins"] = out_pseudo["Empathy_Level_3"]
    out_pseudo["Empathy_Level_3"] = internal_level
    out_pseudo["Empathy_Level_3_Method"] = "cgss2023_internal_tertile_on_mi_score"
    out_pseudo.to_csv(OUT_PSEUDO_PATH, index=False, encoding="utf-8-sig")

    labeled = onehot.copy()
    labeled["Empathy_Score_Pred"] = score
    labeled["Empathy_Score_Uncertainty"] = out_pseudo["Empathy_Score_Uncertainty"]
    labeled["Empathy_Level_3"] = internal_level
    labeled.to_csv(OUT_ONEHOT_PATH, index=False, encoding="utf-8-sig")

    print(f"pseudo saved: {OUT_PSEUDO_PATH} {out_pseudo.shape}")
    print(f"labeled onehot saved: {OUT_ONEHOT_PATH} {labeled.shape}")
    print("\nCGSS2023 internal-tertile bins:")
    print(pd.Series(bins).to_string(index=False))
    print("\nCGSS2023 internal 3-class distribution:")
    print(internal_level.value_counts().sort_index())
    print("\nOriginal seed-bin 3-class distribution:")
    print(out_pseudo["Empathy_Level_3_SeedBins"].value_counts().sort_index())


if __name__ == "__main__":
    main()

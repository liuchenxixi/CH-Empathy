# Datasheet for CH-Empathy v1

## Motivation

CH-Empathy was created to support weak-empathy modeling and construct-validity analysis using semantically organized Chinese social-survey variables.

## Composition

The public release contains metadata, recoding rules, reconstruction scripts, benchmark scripts, validation scripts, split configuration, and aggregate results. It does not contain CGSS2023 raw data, CGSS row-level derived records, or raw seed-survey records.

## Collection Process

The schema aligns seed-survey variables with CGSS2023-compatible constructs. Authorized users can reconstruct CGSS2023-derived features locally with the included scripts. Weak-empathy labels are produced by a teacher-model pipeline and discretized into three internal classes for benchmark evaluation.

## Preprocessing

Variables are recoded into semantic categories and one-hot encoded for model training. Special values include unknown or missing categories and not-applicable spouse-related categories. Exact recoding logic is provided in `scripts/feature_schema.py` and `scripts/reconstruct_cgss2023.py`.

## Uses

Recommended uses include benchmark evaluation, construct-validity analysis, schema inspection, and reproducibility checks. The resource should not be used for individual-level diagnosis, eligibility decisions, surveillance, or attempts to infer private attributes about identifiable people.

## Distribution

The package is suitable for upload to DOI-providing repositories. CGSS2023 data must be obtained separately from the official provider and used under its original terms.

## Maintenance

Future versions should update the DOI record with versioned archives, expanded metadata, additional validation results, and corrected scripts or documentation when needed.
